import { describe, expect, it } from "vitest";
import { PLANS, getPlan, hasPublishingEntitlement } from "../src/lib/plans";

describe("planos comerciais", () => {
  it("mantém os preços e limites definidos", () => {
    expect(PLANS.free).toMatchObject({ priceCents: 0, durationDays: 30, dailyLimit: 10 });
    expect(PLANS.professional).toMatchObject({ priceCents: 9700, durationDays: 30, dailyLimit: 30 });
    expect(PLANS.business).toMatchObject({ priceCents: 69700, durationDays: 365, dailyLimit: 100 });
  });

  it("usa o plano Free como fallback para um código desconhecido", () => {
    expect(getPlan("unknown").code).toBe("free");
  });

  it("reserva publicação a planos pagos com período vigente", () => {
    const now = new Date("2026-10-30T12:00:00.000Z");
    expect(hasPublishingEntitlement({ planCode: "professional", status: "active", currentPeriodEnd: "2026-11-29T12:00:00.000Z", now })).toBe(true);
    expect(hasPublishingEntitlement({ planCode: "business", status: "trialing", currentPeriodEnd: "2027-10-30T12:00:00.000Z", now })).toBe(true);
    expect(hasPublishingEntitlement({ planCode: "free", status: "active", currentPeriodEnd: "2026-11-29T12:00:00.000Z", now })).toBe(false);
    expect(hasPublishingEntitlement({ planCode: "professional", status: "expired", currentPeriodEnd: "2026-11-29T12:00:00.000Z", now })).toBe(false);
    expect(hasPublishingEntitlement({ planCode: "professional", status: "active", currentPeriodEnd: "2026-10-29T12:00:00.000Z", now })).toBe(false);
  });
});
