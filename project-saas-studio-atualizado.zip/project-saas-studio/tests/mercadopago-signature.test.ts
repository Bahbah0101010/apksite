import { createHmac } from "node:crypto";
import { describe, expect, it } from "vitest";
import { validateMercadoPagoSignature } from "../src/lib/mercadopago";

describe("validação da assinatura do Mercado Pago", () => {
  it("aceita um HMAC correspondente ao manifesto", () => {
    const secret = "segredo-de-teste";
    const dataId = "123456";
    const requestId = "request-abc";
    const ts = "1704908010";
    const manifest = `id:${dataId};request-id:${requestId};ts:${ts};`;
    const v1 = createHmac("sha256", secret).update(manifest).digest("hex");
    expect(validateMercadoPagoSignature({ signature: `ts=${ts},v1=${v1}`, requestId, dataId, secret })).toBe(true);
  });

  it("rejeita assinatura alterada ou incompleta", () => {
    expect(validateMercadoPagoSignature({ signature: "ts=1,v1=deadbeef", requestId: "x", dataId: "1", secret: "s" })).toBe(false);
    expect(validateMercadoPagoSignature({ signature: null, requestId: "x", dataId: "1", secret: "s" })).toBe(false);
  });
});
