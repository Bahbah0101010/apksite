# Studio — base comercial de Project SaaS

Projeto-fonte para uma plataforma de criação e publicação de sites. A identidade visual usa papel, off-white, grafite, terracota discreto e tipografia editorial. Não usa estética cyberpunk, neon, hologramas nem elementos decorativos que tentem parecer uma IA.

> **Estado desta entrega:** contém melhorias concretas no código e assets de identidade visual, mas ainda não é um serviço publicado, não possui credenciais externas, não foi testado contra contas de produção e não contém APK compilado. Não use para receber pagamentos de clientes antes de configurar e validar os serviços externos.

## 1. Arquitetura

- **Web:** Next.js App Router, React e TypeScript.
- **Android:** Capacitor 8 preparado para gerar o projeto nativo com `npm run cap:add:android`. O contêiner, depois de compilado, usa a mesma aplicação web hospedada, o mesmo backend e o mesmo banco da versão web.
- **Autenticação e dados:** Supabase Auth + PostgreSQL + RLS.
- **IA:** endpoint compatível com OpenAI Chat Completions, configurável por variáveis privadas. O código não fixa um provedor.
- **Pagamentos:** Mercado Pago Checkout Pro com preferência criada no servidor e confirmação pelo webhook consultando a API do provedor.
- **Presença:** heartbeat autenticado a cada 30 segundos; online é definido como atividade nos últimos 90 segundos.
- **Analytics:** eventos de page view e visitantes pseudonimizados somente depois do consentimento opcional.

O App Router e o helper SSR do Supabase foram escolhidos para manter a sessão por cookies e executar validações sensíveis no servidor. Consulte a documentação atual do [Next.js](https://nextjs.org/docs/app) e do [Supabase SSR](https://supabase.com/docs/guides/auth/server-side/creating-a-client?framework=nextjs).

## 2. O que já está implementado no código

- Landing page responsiva com identidade visual editorial.
- Cadastro e login pelo Supabase Auth.
- Dashboard de cliente com plano, uso diário e projetos.
- Gerador que valida os dados, consulta um provedor de IA configurado e salva o resultado no banco.
- Reserva e confirmação transacional da cota: falhas não devem consumir geração.
- Editor com texto, cor, tipografia, logotipo, imagem de capa, produtos/serviços, seções reordenáveis, prévia mobile/tablet/desktop, upload de imagens ao Supabase Storage e autosave.
- Histórico de revisões com restauração da versão anterior.
- Fluxo de despublicação de sites.
- Recuperação e redefinição de senha pelo Supabase Auth.
- Publicação por caminho `/s/slug` no mesmo domínio da plataforma.
- Checkout criado no backend, registro de tentativa e confirmação do pagamento por webhook assinado e consulta à API do Mercado Pago.
- Renovação manual dos planos pagos. Este projeto não promete cobrança recorrente automática.
- Presença de contas autenticadas com heartbeat; contas e sessões são contadas separadamente.
- Analytics consentido, com visitantes estimados por identificador pseudonimizado e sessões agregadas nas últimas 24 horas. Ainda não há contador de visitantes anônimos online em tempo real.
- Painel administrativo de métricas alimentado por uma função SQL. Pagamentos em modo de teste são excluídos do financeiro de produção.
- SQL inicial com tabelas, índices, constraints, RLS, cotas e rotina transacional de confirmação do pagamento.
- Migration `0002_editor_assets_and_usage.sql` com histórico de versões, bucket de imagens com políticas RLS e métricas reais de consumo de IA.
- Configuração inicial do Capacitor para gerar o projeto Android.

## 3. Planos cadastrados

| Plano | Preço | Duração | Gerações por dia |
|---|---:|---:|---:|
| Free | R$ 0,00 | 30 dias | 10 |
| Professional | R$ 97,00 | 30 dias | 30 |
| Business | R$ 697,00 | 365 dias | 100 |

Os valores também estão no servidor (`src/lib/plans.ts`) e na tabela `plans`. O frontend não pode aumentar a cota. O backend reserva a unidade e só a conta depois de salvar o site com sucesso.

## 4. Preparar o backend Supabase

1. Crie um projeto no Supabase.
2. Abra **SQL Editor** e execute `supabase/migrations/0001_initial.sql` em um projeto vazio; em seguida, execute `supabase/migrations/0002_editor_assets_and_usage.sql`.
3. Em **Authentication → Providers**, habilite Email e ajuste a confirmação de e-mail conforme sua política.
4. Em **Database → Publications**, adicione à publicação `supabase_realtime` as tabelas `profiles`, `websites`, `payments`, `subscriptions` e `user_sessions`. O painel usa Realtime e também consulta o endpoint de métricas a cada 30 segundos como recuperação.
5. Cadastre o e-mail do administrador em `ADMIN_EMAILS` no servidor e marque o perfil correspondente como admin usando o SQL abaixo, substituindo o e-mail:

```sql
update public.profiles p
set role = 'admin'
from auth.users u
where p.id = u.id
  and lower(u.email) = lower('admin@seudominio.com');
```

A allowlist do servidor e a função `is_admin()` do banco devem apontar para a mesma conta. Não dê acesso administrativo alterando o frontend.

## 5. Variáveis de ambiente

Copie `.env.example` para `.env.local` e preencha os valores:

- `NEXT_PUBLIC_APP_URL`: URL HTTPS do app já hospedado; em desenvolvimento pode ser `http://localhost:3000`.
- `NEXT_PUBLIC_SUPABASE_URL` e `NEXT_PUBLIC_SUPABASE_ANON_KEY`: valores públicos do projeto Supabase.
- `SUPABASE_SERVICE_ROLE_KEY`: chave privada, apenas no servidor. Nunca use prefixo `NEXT_PUBLIC_`.
- `ADMIN_EMAILS`: e-mails autorizados para acessar a página administrativa.
- `AI_API_BASE_URL`, `AI_API_KEY`, `AI_MODEL`: endereço, chave e modelo do provedor compatível.
- `MERCADOPAGO_ACCESS_TOKEN`: token de teste durante o desenvolvimento; token real somente em produção.
- `MERCADOPAGO_WEBHOOK_SECRET`: segredo exibido na configuração dos webhooks da aplicação do Mercado Pago.
- `MERCADOPAGO_ENV`: `test` ou `production`.
- `ANALYTICS_HASH_SECRET`: segredo aleatório com pelo menos 32 caracteres para gerar identificadores pseudonimizados.

O rate limiting por usuário é aplicado no PostgreSQL pela função `consume_user_rate_limit` (migration 0002). Os endpoints sensíveis falham de forma segura se o controle estiver indisponível. Limites atuais: IA 5/minuto, checkout 3/minuto, publicação/despublicação 10/minuto e métricas administrativas 30/minuto; as cotas diárias de IA continuam sendo verificadas separadamente.
- `CAPACITOR_SERVER_URL`: URL HTTPS publicada que o contêiner Android deve abrir.

Exemplo para criar um segredo aleatório em um terminal com OpenSSL:

```bash
openssl rand -hex 32
```

Não envie `.env.local`, tokens, chaves, senhas ou arquivos de assinatura para repositórios públicos.

## 6. Executar a versão web

Requisitos: Node.js 20.9 ou superior e npm.

```bash
npm install
cp .env.example .env.local
# Preencha .env.local antes de testar integrações.
npm run dev
```

Acesse a URL local exibida pelo Next.js. Para conferir antes da publicação:

```bash
npm run typecheck
npm run lint
npm test
npm run build
```

Sem Supabase configurado, autenticação e banco não funcionam. Sem provedor de IA configurado, o gerador responde com erro de configuração e não consome cota. Sem Mercado Pago e webhook configurados, não existe confirmação financeira.

## 7. Mercado Pago

O fluxo incluído cria uma preferência de Checkout Pro no servidor. O comprador escolhe os meios que o Mercado Pago apresentar para aquela conta e transação. O webhook valida `x-signature`, consulta o pagamento diretamente na API do Mercado Pago, confere referência, moeda e valor e chama uma função SQL transacional. Apenas status aprovado pode ativar um plano.

**Renovação:** neste pacote, Professional e Business são cobranças avulsas com renovação manual após 30 ou 365 dias. Não foi implementada autorização de cobrança recorrente automática. Não anuncie renovação automática no checkout. O funcionamento de Pix e os meios disponíveis precisam ser conferidos no ambiente real da conta do vendedor.

Teste primeiro com credenciais de teste e URL pública de webhook de teste. Depois de concluir os testes, configure credenciais de produção e um banco/projeto de produção separado. Nunca misture pagamentos de teste com faturamento real. A documentação oficial descreve [Checkout Pro e webhooks](https://www.mercadopago.com.br/developers/pt/docs/checkout-pro/overview) e a validação de notificações em [Webhooks](https://www.mercadopago.com.br/developers/en/docs/checkout-bricks/additional-content/your-integrations/notifications/webhooks).

## 8. Android / APK

Esta entrega contém `capacitor.config.ts`, a pasta `www` como fallback, ícones por densidade/adaptativos em `android-assets/` e um conjunto de ícone iOS em `ios-assets/`. O projeto nativo Android ainda precisa ser materializado pelo Capacitor. **Não contém um APK compilado.** O ambiente que criou este ZIP não possui Android Studio, Android SDK nem Gradle instalados.

Com Android Studio, Android SDK e JDK compatíveis instalados:

```bash
npm install
CAPACITOR_SERVER_URL=https://SEU-DOMINIO npx cap add android
CAPACITOR_SERVER_URL=https://SEU-DOMINIO npx cap sync android
npx cap open android
```

No Android Studio, gere o APK pelo menu **Build → Build Bundle(s) / APK(s) → Build APK(s)**. Para distribuição, use **Generate Signed Bundle / APK** e uma chave de assinatura guardada com segurança. Não compartilhe a chave privada.

O app Android é um contêiner Capacitor nativo que abre a aplicação HTTPS hospedada. Ele não é apenas um atalho PWA, mas também não é uma reimplementação de todas as telas em Kotlin. A conexão depende de `CAPACITOR_SERVER_URL` e de um domínio com HTTPS.

### Foto e ícones do aplicativo

A imagem quadrada enviada foi incorporada sem trocar a fotografia nem acrescentar elementos:
- `resources/icon.png` — master quadrado 1024 × 1024 para geradores de assets.
- `resources/splash.png` — imagem quadrada 2732 × 2732 para a tela de abertura.
- `public/icons/` — ícones web/PWA 192, 512, 1024 e Apple Touch Icon 180.
- `public/brand/cover.jpg` — fotografia usada também na identidade visual da landing page.
- `android-assets/` — ícones Android legados por densidade e adaptive icon XML/foreground.
- `ios-assets/AppIcon.appiconset/` — catálogo de ícone iOS 1024 × 1024.

Depois de gerar o projeto nativo, execute `npm run mobile:assets` (ou copie os conjuntos prontos documentados em `android-assets/README.md` e `ios-assets/README.md`). Confira o recorte de máscara em aparelhos iOS e Android antes da publicação.

## 9. Publicação de sites

A publicação funcional incluída usa URL do tipo `https://seu-dominio.com/s/slug`. Para usar `slug.seu-dominio.com`, ainda será necessário configurar DNS wildcard, certificado TLS wildcard e roteamento por hostname no provedor de hospedagem. Domínios personalizados também exigem verificação DNS e TLS; essa automação não está concluída neste pacote.

## 10. Privacidade, presença e métricas

- O analytics só registra visualizações depois de o visitante aceitar analytics opcionais.
- O identificador de visitante é pseudonimizado com SHA-256 e segredo do servidor. Não é uma contagem de pessoas físicas únicas; visitantes anônimos online ainda não são medidos.
- `page_view`, sessão anônima, visitante estimado, conta e sessão autenticada são medidas diferentes. A sessão anônima é agregada no período de 24 horas; não aparece como online agora.
- Uma conta fica online quando um heartbeat foi recebido nos últimos 90 segundos. O heartbeat é enviado a cada 30 segundos enquanto a área autenticada está aberta.
- Se o navegador suspender a página, a presença pode expirar e só volta após novo heartbeat.
- O painel mostra a última consulta bem-sucedida. Se o endpoint falhar, informa o erro e avisa que os dados podem estar desatualizados.
- O financeiro considera somente o ambiente `live`. O faturamento bruto mantém o valor das transações que foram aprovadas, inclusive quando depois aparecem como reembolsadas ou contestadas; estornos e taxas são apresentados separadamente. Se faltar taxa de qualquer transação considerada, a receita líquida aparece como indisponível. Os gráficos usam a data local de São Paulo e a data de aprovação registrada pelo provedor.

Este desenho técnico não substitui política de privacidade, aviso de cookies, termos comerciais, avaliação jurídica ou revisão de conformidade com a LGPD antes de atender clientes reais.

## 11. Limites desta entrega — ainda não declarar como concluído

Os pontos abaixo ainda precisam ser concluídos e testados antes de vender o serviço:

1. Compilar, instalar e testar o APK em aparelhos Android reais; assinar a versão de distribuição.
2. Validar visualmente ícones e tela de abertura em aparelhos iOS/Android; os arquivos de origem já estão incluídos.
3. Publicar em domínio próprio com DNS, HTTPS, backups, monitoramento e ambientes separados.
4. Configurar wildcard/subdomínios e domínios personalizados. A publicação atual é por caminho `/s/slug`.
5. Concluir funcionalidades editoriais ainda ausentes, como upload em lote, formulários, SEO avançado e editor de domínios.
6. Implementar todos os recursos de cliente prometidos nos três planos, incluindo analytics dos sites publicados e gerenciamento de vários negócios.
7. Criar CRUD administrativo completo para usuários, planos, limites, bloqueios, cancelamentos, reembolsos e auditoria.
8. Completar edição de perfil e exclusão de conta com confirmação e limpeza de dados.
9. Adicionar controle de custos/token por provedor e limites de armazenamento/tráfego.
10. Implementar presença online para visitantes anônimos com heartbeat consentido e ampliar os gráficos para todos os indicadores agregados.
11. Executar testes reais de ponta a ponta com projeto Supabase, provedor de IA e credenciais de teste do Mercado Pago; em seguida, fazer revisão de segurança.

O pacote não cria contas, clientes, visitas, usuários online, avaliações, sites ou pagamentos de demonstração. Métricas vazias permanecem em zero ou são indisponíveis conforme o retorno do banco.
