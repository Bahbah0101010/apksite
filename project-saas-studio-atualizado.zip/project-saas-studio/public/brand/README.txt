IMAGEM PRINCIPAL DA MARCA

A fotografia fornecida foi integrada em cover.jpg. Ela também é a base do ícone de aplicativo
quadrado em resources/icon.png, resources/splash.png, public/icons/ e nos conjuntos
android-assets/ e ios-assets/.

Preserve a imagem e não substitua por outra sem autorização.
