import type { CapacitorConfig } from "@capacitor/cli";

const remoteUrl = process.env.CAPACITOR_SERVER_URL?.trim();

const config: CapacitorConfig = {
  appId: "com.projectsaas.studio",
  appName: "Studio",
  webDir: "www",
  bundledWebRuntime: false,
  backgroundColor: "#F5F1EB",
  android: {
    allowMixedContent: false,
    captureInput: true,
  },
  ...(remoteUrl
    ? { server: { url: remoteUrl, cleartext: false, androidScheme: "https" as const } }
    : {}),
};

export default config;
