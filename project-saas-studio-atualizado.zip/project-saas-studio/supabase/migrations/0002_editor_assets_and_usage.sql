-- Complementos de segurança, histórico de edição e analytics de consumo.
-- Execute após 0001_initial.sql no mesmo projeto Supabase.

-- Impede publicar sites alterando diretamente status/slug via chave anon/authenticated.
-- Edição normal fica limitada a nome e conteúdo; publicação passa pelos endpoints do servidor.
revoke insert,update on public.websites from authenticated;
grant select,delete on public.websites to authenticated;
grant update(name,content,updated_at) on public.websites to authenticated;

-- A leitura pública precisa somente dos campos renderizados pelo site publicado.
revoke select on public.websites from anon;
grant select(name,content,slug,status,published_at) on public.websites to anon;

create table if not exists public.website_revisions (
  id uuid primary key default gen_random_uuid(),
  website_id uuid not null references public.websites(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  name text not null check (char_length(name) between 2 and 80),
  content jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);
create index if not exists website_revisions_owner_created_idx
  on public.website_revisions(website_id,user_id,created_at desc);

alter table public.website_revisions enable row level security;
drop policy if exists "website revisions read own" on public.website_revisions;
create policy "website revisions read own"
  on public.website_revisions for select to authenticated
  using (
    user_id=auth.uid()
    and exists (select 1 from public.websites w where w.id=website_id and w.user_id=auth.uid())
  );
drop policy if exists "website revisions insert own" on public.website_revisions;
revoke insert,update,delete on public.website_revisions from authenticated;
grant select on public.website_revisions to authenticated;
grant all on public.website_revisions to service_role;

-- Bucket público para leitura de imagens de sites publicados.
-- Escrita, substituição e remoção ficam restritas ao proprietário do site.
insert into storage.buckets (id,name,public,file_size_limit,allowed_mime_types)
values (
  'website-assets',
  'website-assets',
  true,
  8388608,
  array['image/jpeg','image/png','image/webp']
)
on conflict (id) do update set
  public=true,
  file_size_limit=8388608,
  allowed_mime_types=array['image/jpeg','image/png','image/webp'];

drop policy if exists "website assets owner read" on storage.objects;
create policy "website assets owner read"
  on storage.objects for select to authenticated
  using (
    bucket_id='website-assets'
    and split_part(name,'/',1) ~* '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'
    and exists (
      select 1 from public.websites w
      where lower(w.id::text)=lower(split_part(name,'/',1)) and w.user_id=auth.uid()
    )
  );

drop policy if exists "website assets owner insert" on storage.objects;
create policy "website assets owner insert"
  on storage.objects for insert to authenticated
  with check (
    bucket_id='website-assets'
    and split_part(name,'/',1) ~* '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'
    and exists (
      select 1 from public.websites w
      where lower(w.id::text)=lower(split_part(name,'/',1)) and w.user_id=auth.uid()
    )
  );

drop policy if exists "website assets owner update" on storage.objects;
create policy "website assets owner update"
  on storage.objects for update to authenticated
  using (
    bucket_id='website-assets'
    and split_part(name,'/',1) ~* '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'
    and exists (
      select 1 from public.websites w
      where lower(w.id::text)=lower(split_part(name,'/',1)) and w.user_id=auth.uid()
    )
  )
  with check (
    bucket_id='website-assets'
    and split_part(name,'/',1) ~* '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'
    and exists (
      select 1 from public.websites w
      where lower(w.id::text)=lower(split_part(name,'/',1)) and w.user_id=auth.uid()
    )
  );

drop policy if exists "website assets owner delete" on storage.objects;
create policy "website assets owner delete"
  on storage.objects for delete to authenticated
  using (
    bucket_id='website-assets'
    and split_part(name,'/',1) ~* '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'
    and exists (
      select 1 from public.websites w
      where lower(w.id::text)=lower(split_part(name,'/',1)) and w.user_id=auth.uid()
    )
  );

-- O dashboard administrativo recebe dados de consumo diretamente do PostgreSQL.
create or replace function public.admin_generation_metrics()
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  day_key date := (now() at time zone 'America/Sao_Paulo')::date;
  metrics jsonb;
begin
  if coalesce(auth.role(),'') <> 'service_role' then
    raise exception 'not_allowed';
  end if;

  with days as (
    select series.day_ts::date as day
    from generate_series(day_key - 6, day_key, interval '1 day') as series(day_ts)
  ),
  totals as (
    select
      coalesce(sum(successful_count) filter (where usage_day=day_key),0)::bigint as successful_today,
      coalesce(sum(reserved_count) filter (where usage_day=day_key),0)::bigint as reserved_today,
      count(distinct user_id) filter (where usage_day=day_key and successful_count>0)::bigint as active_generators_today,
      coalesce(sum(successful_count) filter (where usage_day>=day_key-6),0)::bigint as successful_7d
    from public.generation_usage
    where usage_day between day_key-6 and day_key
  )
  select jsonb_build_object(
    'successful_today',totals.successful_today,
    'reserved_today',totals.reserved_today,
    'active_generators_today',totals.active_generators_today,
    'successful_7d',totals.successful_7d,
    'daily',coalesce((select jsonb_agg(item order by (item->>'day')) from (
      select jsonb_build_object(
        'day',d.day,
        'successful',coalesce(sum(g.successful_count),0)::bigint,
        'reserved',coalesce(sum(g.reserved_count),0)::bigint
      ) as item
      from days d
      left join public.generation_usage g on g.usage_day=d.day
      group by d.day
    ) s),'[]'::jsonb)
  ) into metrics
  from totals;

  return metrics;
end;
$$;

revoke all on function public.admin_generation_metrics() from public,anon,authenticated;
grant execute on function public.admin_generation_metrics() to service_role;

-- Limitador atômico por usuário/rota para endpoints sensíveis.
create table if not exists public.api_rate_limits (
  user_id uuid not null references auth.users(id) on delete cascade,
  scope text not null check (char_length(scope) between 1 and 80),
  window_started_at timestamptz not null default now(),
  request_count integer not null default 0 check (request_count >= 0),
  updated_at timestamptz not null default now(),
  primary key (user_id,scope)
);
alter table public.api_rate_limits enable row level security;
revoke all on public.api_rate_limits from public,anon,authenticated;
grant all on public.api_rate_limits to service_role;

create or replace function public.consume_user_rate_limit(
  p_user_id uuid,
  p_scope text,
  p_limit integer,
  p_window_seconds integer
)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  current_count integer;
  window_start timestamptz;
  retry_seconds integer;
begin
  if coalesce(auth.role(),'') <> 'service_role' then
    raise exception 'not_allowed';
  end if;
  if p_user_id is null or p_scope is null or char_length(p_scope) not between 1 and 80
     or p_limit < 1 or p_limit > 1000 or p_window_seconds < 1 or p_window_seconds > 86400 then
    raise exception 'invalid_rate_limit_arguments';
  end if;

  insert into public.api_rate_limits as current_limit(user_id,scope,window_started_at,request_count,updated_at)
  values (p_user_id,p_scope,now(),1,now())
  on conflict (user_id,scope) do update set
    window_started_at = case
      when current_limit.window_started_at + make_interval(secs => p_window_seconds) <= now()
        then now()
      else current_limit.window_started_at
    end,
    request_count = case
      when current_limit.window_started_at + make_interval(secs => p_window_seconds) <= now()
        then 1
      else current_limit.request_count + 1
    end,
    updated_at = now()
  returning request_count,window_started_at into current_count,window_start;

  if current_count > p_limit then
    retry_seconds := greatest(1,ceil(extract(epoch from (window_start + make_interval(secs => p_window_seconds) - now())))::integer);
    return jsonb_build_object('allowed',false,'remaining',0,'retry_after_seconds',retry_seconds);
  end if;
  return jsonb_build_object('allowed',true,'remaining',p_limit-current_count,'retry_after_seconds',0);
end;
$$;
revoke all on function public.consume_user_rate_limit(uuid,text,integer,integer) from public,anon,authenticated;
grant execute on function public.consume_user_rate_limit(uuid,text,integer,integer) to service_role;
