-- Studio / Project SaaS: schema inicial.
-- Execute em um projeto Supabase vazio. Não rode em produção sem backup e revisão.

create extension if not exists pgcrypto;

create table if not exists public.plans (
  code text primary key check (code in ('free','professional','business')),
  name text not null,
  price_cents integer not null check (price_cents >= 0),
  currency text not null default 'BRL' check (currency = 'BRL'),
  duration_days integer not null check (duration_days > 0),
  daily_limit integer not null check (daily_limit >= 0),
  billing_label text not null,
  active boolean not null default true,
  features jsonb not null default '[]'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

insert into public.plans (code,name,price_cents,duration_days,daily_limit,billing_label,features)
values
  ('free','Free',0,30,10,'30 dias','["10 gerações por dia","Modelos gratuitos","Editor básico","SEO básico","Projetos salvos"]'::jsonb),
  ('professional','Professional',9700,30,30,'por mês','["30 gerações por dia","Modelos premium","Editor completo","Publicação","Estatísticas","Suporte prioritário"]'::jsonb),
  ('business','Business',69700,365,100,'por ano','["100 gerações por dia","Todos os modelos","Vários negócios","Estatísticas avançadas","Editor completo","Suporte prioritário"]'::jsonb)
on conflict (code) do update set
  name=excluded.name, price_cents=excluded.price_cents, duration_days=excluded.duration_days,
  daily_limit=excluded.daily_limit, billing_label=excluded.billing_label, features=excluded.features,
  updated_at=now();

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  role text not null default 'user' check (role in ('user','admin')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.subscriptions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  plan_code text not null references public.plans(code),
  status text not null check (status in ('active','trialing','past_due','cancelled','expired')),
  started_at timestamptz not null default now(),
  current_period_start timestamptz not null default now(),
  current_period_end timestamptz not null,
  payment_id uuid,
  mp_preapproval_id text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists subscriptions_user_status_idx on public.subscriptions(user_id,status,created_at desc);

create table if not exists public.websites (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  name text not null check (char_length(name) between 2 and 80),
  category text not null default 'servicos',
  slug text unique,
  status text not null default 'draft' check (status in ('draft','published','unpublished')),
  content jsonb not null default '{}'::jsonb,
  generation_source text not null default 'manual' check (generation_source in ('manual','ai','imported')),
  published_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists websites_user_created_idx on public.websites(user_id,created_at desc);
create index if not exists websites_published_slug_idx on public.websites(slug) where status='published';

create table if not exists public.website_sections (
  id uuid primary key default gen_random_uuid(),
  website_id uuid not null references public.websites(id) on delete cascade,
  section_key text not null,
  sort_order integer not null default 0,
  content jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (website_id,section_key)
);

create table if not exists public.website_products (
  id uuid primary key default gen_random_uuid(),
  website_id uuid not null references public.websites(id) on delete cascade,
  name text not null,
  description text,
  price_cents integer check (price_cents is null or price_cents >= 0),
  image_path text,
  active boolean not null default true,
  sort_order integer not null default 0,
  created_at timestamptz not null default now()
);

create table if not exists public.website_assets (
  id uuid primary key default gen_random_uuid(),
  website_id uuid not null references public.websites(id) on delete cascade,
  storage_path text not null,
  mime_type text,
  size_bytes bigint,
  alt_text text,
  created_at timestamptz not null default now()
);

create table if not exists public.website_domains (
  id uuid primary key default gen_random_uuid(),
  website_id uuid not null references public.websites(id) on delete cascade,
  hostname text not null unique,
  verified_at timestamptz,
  status text not null default 'pending' check (status in ('pending','verified','active','disabled')),
  created_at timestamptz not null default now()
);

create table if not exists public.generation_usage (
  user_id uuid not null references auth.users(id) on delete cascade,
  usage_day date not null,
  successful_count integer not null default 0 check (successful_count >= 0),
  reserved_count integer not null default 0 check (reserved_count >= 0),
  updated_at timestamptz not null default now(),
  primary key (user_id,usage_day)
);

create table if not exists public.payments (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete restrict,
  plan_code text not null references public.plans(code),
  provider text not null default 'mercadopago',
  provider_preference_id text,
  provider_payment_id text unique,
  external_reference text not null unique,
  checkout_url text,
  status text not null default 'pending' check (status in ('pending','approved','rejected','cancelled','refunded','chargeback')),
  amount_cents integer not null check (amount_cents >= 0),
  fee_cents integer check (fee_cents is null or fee_cents >= 0),
  refunded_cents integer not null default 0 check (refunded_cents >= 0),
  currency text not null default 'BRL' check (currency='BRL'),
  mode text not null default 'test' check (mode in ('test','live')),
  provider_status_detail text,
  failure_reason text,
  approved_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists payments_created_status_idx on public.payments(created_at desc,status,mode);
create index if not exists payments_user_idx on public.payments(user_id,created_at desc);

alter table public.subscriptions drop constraint if exists subscriptions_payment_id_fkey;
alter table public.subscriptions add constraint subscriptions_payment_id_fkey
  foreign key (payment_id) references public.payments(id) on delete set null;

create table if not exists public.payment_events (
  id uuid primary key default gen_random_uuid(),
  provider text not null,
  provider_event_id text not null unique,
  payment_id uuid references public.payments(id) on delete set null,
  event_type text not null,
  payload jsonb not null default '{}'::jsonb,
  received_at timestamptz not null default now()
);

create table if not exists public.platform_events (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete set null,
  event_type text not null,
  payload jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);
create index if not exists platform_events_created_idx on public.platform_events(created_at desc);

create table if not exists public.user_sessions (
  session_id uuid primary key,
  user_id uuid not null references auth.users(id) on delete cascade,
  current_path text not null default '/app',
  user_agent text,
  started_at timestamptz not null default now(),
  last_seen timestamptz not null default now()
);
create index if not exists user_sessions_last_seen_idx on public.user_sessions(last_seen desc);
create index if not exists user_sessions_user_idx on public.user_sessions(user_id,last_seen desc);

create table if not exists public.visitor_sessions (
  visitor_key text primary key,
  first_seen timestamptz not null default now(),
  last_seen timestamptz not null default now(),
  referrer text,
  user_agent text,
  consented boolean not null default false
);

create table if not exists public.analytics_events (
  id uuid primary key default gen_random_uuid(),
  event_type text not null,
  visitor_key text,
  session_id uuid,
  user_id uuid references auth.users(id) on delete set null,
  website_id uuid references public.websites(id) on delete set null,
  page_path text not null,
  referrer text,
  user_agent text,
  is_bot boolean not null default false,
  created_at timestamptz not null default now()
);
create index if not exists analytics_events_created_idx on public.analytics_events(created_at desc);
create index if not exists analytics_events_visitor_idx on public.analytics_events(visitor_key,created_at desc);

create table if not exists public.audit_logs (
  id uuid primary key default gen_random_uuid(),
  actor_user_id uuid references auth.users(id) on delete set null,
  action text not null,
  target_type text,
  target_id text,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  display_name text;
begin
  display_name := nullif(new.raw_user_meta_data ->> 'full_name','');
  insert into public.profiles(id,full_name) values (new.id,display_name)
  on conflict (id) do nothing;
  insert into public.subscriptions(user_id,plan_code,status,started_at,current_period_start,current_period_end)
  values (new.id,'free','active',now(),now(),now() + interval '30 days');
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute procedure public.handle_new_user();

create or replace function public.reserve_generation(p_user_id uuid)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  active_plan text;
  daily_cap integer;
  day_key date := (now() at time zone 'America/Sao_Paulo')::date;
  used integer;
  reserved integer;
begin
  if coalesce(auth.role(),'') <> 'service_role' then
    raise exception 'not_allowed';
  end if;

  select s.plan_code, p.daily_limit into active_plan, daily_cap
  from public.subscriptions s
  join public.plans p on p.code=s.plan_code and p.active=true
  where s.user_id=p_user_id and s.status in ('active','trialing') and s.current_period_end > now()
  order by s.created_at desc limit 1;

  if active_plan is null then
    return jsonb_build_object('ok',false,'reason','Seu período gratuito terminou. Escolha um plano para continuar.');
  end if;

  insert into public.generation_usage(user_id,usage_day,successful_count,reserved_count)
  values (p_user_id,day_key,0,0) on conflict (user_id,usage_day) do nothing;

  select successful_count,reserved_count into used,reserved
  from public.generation_usage where user_id=p_user_id and usage_day=day_key for update;

  if used + reserved >= daily_cap then
    return jsonb_build_object('ok',false,'reason','Você atingiu o limite de gerações de hoje.');
  end if;

  update public.generation_usage set reserved_count=reserved_count+1,updated_at=now()
  where user_id=p_user_id and usage_day=day_key;
  return jsonb_build_object('ok',true,'usage_day',day_key,'remaining_after_reservation',greatest(0,daily_cap-used-reserved-1));
end;
$$;

create or replace function public.complete_generation(p_user_id uuid,p_usage_day date,p_success boolean)
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  if coalesce(auth.role(),'') <> 'service_role' then
    raise exception 'not_allowed';
  end if;
  update public.generation_usage
  set reserved_count=greatest(0,reserved_count-1),
      successful_count=successful_count + case when p_success then 1 else 0 end,
      updated_at=now()
  where user_id=p_user_id and usage_day=p_usage_day;
end;
$$;

create or replace function public.admin_dashboard_metrics()
returns jsonb
language sql
security definer
set search_path = public
as $$
with
accounts as (
  select count(*)::bigint total,
         count(*) filter (where created_at >= now()-interval '24 hours')::bigint new_24h
  from public.profiles
),
presence as (
  select count(distinct user_id)::bigint accounts_online, count(*)::bigint sessions_online
  from public.user_sessions where last_seen >= now()-interval '90 seconds'
),
traffic as (
  select count(*)::bigint views_24h,
         count(distinct visitor_key)::bigint unique_visitors_24h,
         count(distinct session_id)::bigint sessions_24h
  from public.analytics_events
  where created_at >= now()-interval '24 hours' and event_type='page_view' and is_bot=false
),
sites as (
  select count(*)::bigint total, count(*) filter (where status='published')::bigint published
  from public.websites
),
subs as (
  select count(*) filter (where plan_code='free')::bigint free,
         count(*) filter (where plan_code='professional')::bigint professional,
         count(*) filter (where plan_code='business')::bigint business,
         count(*)::bigint total
  from public.subscriptions
  where status in ('active','trialing') and current_period_end > now()
),
pay as (
  select count(*) filter (where status in ('approved','refunded','chargeback'))::bigint approved,
         count(*) filter (where status='pending')::bigint pending,
         count(*) filter (where status='rejected')::bigint rejected,
         count(*) filter (where status in ('refunded','chargeback'))::bigint refunded,
         coalesce(sum(amount_cents) filter (where status in ('approved','refunded','chargeback')),0)::bigint gross_cents,
         coalesce(sum(fee_cents) filter (where status in ('approved','refunded','chargeback')),0)::bigint fee_cents,
         coalesce(sum(refunded_cents) filter (where status in ('approved','refunded','chargeback')),0)::bigint refunded_cents,
         count(*) filter (where status in ('approved','refunded','chargeback') and fee_cents is null)::bigint missing_fee_count
  from public.payments where mode='live'
),
series_days as (
  select d::date as day,
         (d::date::timestamp at time zone 'America/Sao_Paulo') as day_start,
         ((d::date + 1)::timestamp at time zone 'America/Sao_Paulo') as day_end
  from generate_series(
    (((now() at time zone 'America/Sao_Paulo')::date - 6)::timestamp),
    ((now() at time zone 'America/Sao_Paulo')::date::timestamp),
    interval '1 day'
  ) d
),
series as (
  select jsonb_agg(jsonb_build_object(
    'day',sd.day,
    'signups',(select count(*) from public.profiles p where p.created_at >= sd.day_start and p.created_at < sd.day_end),
    'views',(select count(*) from public.analytics_events a where a.created_at >= sd.day_start and a.created_at < sd.day_end and a.event_type='page_view' and a.is_bot=false),
    'payments',(select count(*) from public.payments pm where pm.approved_at >= sd.day_start and pm.approved_at < sd.day_end and pm.status in ('approved','refunded','chargeback') and pm.mode='live'),
    'revenue_cents',(select coalesce(sum(pm.amount_cents),0) from public.payments pm where pm.approved_at >= sd.day_start and pm.approved_at < sd.day_end and pm.status in ('approved','refunded','chargeback') and pm.mode='live')
  ) order by sd.day) items
  from series_days sd
)
select jsonb_build_object(
  'accounts',(select to_jsonb(accounts) from accounts),
  'presence',(select to_jsonb(presence) from presence),
  'traffic',(select to_jsonb(traffic) from traffic),
  'sites',(select to_jsonb(sites) from sites),
  'subscriptions',(select to_jsonb(subs) from subs),
  'payments',(select jsonb_build_object(
    'approved',approved,'pending',pending,'rejected',rejected,'refunded',refunded,
    'gross_cents',gross_cents,'fee_cents',fee_cents,'refunded_cents',refunded_cents,
    'net_cents',case when missing_fee_count=0 then gross_cents-fee_cents-refunded_cents else null end
  ) from pay),
  'series',coalesce((select items from series),'[]'::jsonb),
  'online_definition','Conta com heartbeat recebido nos últimos 90 segundos. Sessões e contas são contadas separadamente.'
);
$$;

create or replace function public.is_admin()
returns boolean
language sql stable security definer
set search_path = public
as $$
  select exists (select 1 from public.profiles where id=auth.uid() and role='admin');
$$;

-- RLS: as tabelas privadas não podem ser consultadas por outra conta.
alter table public.plans enable row level security;
alter table public.profiles enable row level security;
alter table public.subscriptions enable row level security;
alter table public.websites enable row level security;
alter table public.website_sections enable row level security;
alter table public.website_products enable row level security;
alter table public.website_assets enable row level security;
alter table public.website_domains enable row level security;
alter table public.generation_usage enable row level security;
alter table public.payments enable row level security;
alter table public.payment_events enable row level security;
alter table public.platform_events enable row level security;
alter table public.user_sessions enable row level security;
alter table public.visitor_sessions enable row level security;
alter table public.analytics_events enable row level security;
alter table public.audit_logs enable row level security;

create policy "plans read active" on public.plans for select to anon,authenticated using (active=true or public.is_admin());
create policy "profile read own or admin" on public.profiles for select to authenticated using (id=auth.uid() or public.is_admin());
create policy "profile update own" on public.profiles for update to authenticated using (id=auth.uid()) with check (id=auth.uid() and role='user');
create policy "subscription read own or admin" on public.subscriptions for select to authenticated using (user_id=auth.uid() or public.is_admin());
create policy "website owner all" on public.websites for all to authenticated using (user_id=auth.uid() or public.is_admin()) with check (user_id=auth.uid() or public.is_admin());
create policy "published websites public read" on public.websites for select to anon,authenticated using (status='published');
create policy "sections owner all" on public.website_sections for all to authenticated using (exists(select 1 from public.websites w where w.id=website_id and (w.user_id=auth.uid() or public.is_admin()))) with check (exists(select 1 from public.websites w where w.id=website_id and (w.user_id=auth.uid() or public.is_admin())));
create policy "products owner all" on public.website_products for all to authenticated using (exists(select 1 from public.websites w where w.id=website_id and (w.user_id=auth.uid() or public.is_admin()))) with check (exists(select 1 from public.websites w where w.id=website_id and (w.user_id=auth.uid() or public.is_admin())));
create policy "assets owner all" on public.website_assets for all to authenticated using (exists(select 1 from public.websites w where w.id=website_id and (w.user_id=auth.uid() or public.is_admin()))) with check (exists(select 1 from public.websites w where w.id=website_id and (w.user_id=auth.uid() or public.is_admin())));
create policy "domains owner all" on public.website_domains for all to authenticated using (exists(select 1 from public.websites w where w.id=website_id and (w.user_id=auth.uid() or public.is_admin()))) with check (exists(select 1 from public.websites w where w.id=website_id and (w.user_id=auth.uid() or public.is_admin())));
create policy "generation usage read own" on public.generation_usage for select to authenticated using (user_id=auth.uid() or public.is_admin());
create policy "payments read own or admin" on public.payments for select to authenticated using (user_id=auth.uid() or public.is_admin());
create policy "payment events admin read" on public.payment_events for select to authenticated using (public.is_admin());
create policy "platform events owner or admin read" on public.platform_events for select to authenticated using (user_id=auth.uid() or public.is_admin());
create policy "sessions owner or admin read" on public.user_sessions for select to authenticated using (user_id=auth.uid() or public.is_admin());
create policy "visitor session admin read" on public.visitor_sessions for select to authenticated using (public.is_admin());
create policy "analytics admin read" on public.analytics_events for select to authenticated using (public.is_admin());
create policy "audit admin read" on public.audit_logs for select to authenticated using (public.is_admin());

-- Funções privilegiadas: execução apenas pela chave service_role no backend.
revoke all on function public.reserve_generation(uuid) from public,anon,authenticated;
revoke all on function public.complete_generation(uuid,date,boolean) from public,anon,authenticated;
revoke all on function public.admin_dashboard_metrics() from public,anon,authenticated;
grant execute on function public.reserve_generation(uuid) to service_role;
grant execute on function public.complete_generation(uuid,date,boolean) to service_role;
grant execute on function public.admin_dashboard_metrics() to service_role;

grant select on public.plans to anon,authenticated;
grant select,update on public.profiles to authenticated;
grant select on public.subscriptions,public.generation_usage,public.payments,public.platform_events,public.user_sessions to authenticated;
grant select,delete on public.websites to authenticated;
grant update(name,content,updated_at) on public.websites to authenticated;
grant select,insert,update,delete on public.website_sections,public.website_products,public.website_assets,public.website_domains to authenticated;
grant select on public.payment_events,public.visitor_sessions,public.analytics_events,public.audit_logs to authenticated;

-- Processa pagamentos e renova o acesso dentro de uma única transação.
create or replace function public.process_mercadopago_payment(
  p_external_reference text,
  p_provider_payment_id text,
  p_status text,
  p_amount_cents integer,
  p_fee_cents integer,
  p_refunded_cents integer,
  p_currency text,
  p_mode text,
  p_approved_at timestamptz,
  p_status_detail text,
  p_event_id text,
  p_payload jsonb
)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  local_row public.payments%rowtype;
  inserted_event uuid;
  plan_row public.plans%rowtype;
  current_row public.subscriptions%rowtype;
  period_start timestamptz;
  period_end timestamptz;
  next_status text;
begin
  if coalesce(auth.role(),'') <> 'service_role' then
    raise exception 'not_allowed';
  end if;
  if p_status not in ('pending','approved','rejected','cancelled','refunded','chargeback') then
    raise exception 'invalid_payment_status';
  end if;
  if p_currency <> 'BRL' or p_mode not in ('test','live') then
    raise exception 'invalid_currency_or_mode';
  end if;

  select * into local_row from public.payments
  where external_reference=p_external_reference and provider='mercadopago'
  for update;
  if not found then return jsonb_build_object('ok',false,'reason','payment_not_found'); end if;
  if local_row.amount_cents <> p_amount_cents or local_row.mode <> p_mode then
    return jsonb_build_object('ok',false,'reason','payment_mismatch');
  end if;

  insert into public.payment_events(provider,provider_event_id,payment_id,event_type,payload)
  values ('mercadopago',p_event_id,local_row.id,'payment.'||p_status,coalesce(p_payload,'{}'::jsonb))
  on conflict (provider_event_id) do nothing
  returning id into inserted_event;
  if inserted_event is null then
    return jsonb_build_object('ok',true,'duplicate',true);
  end if;

  next_status := p_status;
  -- Notificações atrasadas não podem rebaixar uma cobrança já aprovada.
  if local_row.status='approved' and p_status in ('pending','rejected','cancelled') then
    next_status := 'approved';
  end if;

  update public.payments set
    provider_payment_id=p_provider_payment_id,
    status=next_status,
    fee_cents=coalesce(p_fee_cents,fee_cents),
    refunded_cents=greatest(refunded_cents,coalesce(p_refunded_cents,0)),
    approved_at=coalesce(p_approved_at,approved_at),
    provider_status_detail=p_status_detail,
    updated_at=now()
  where id=local_row.id;

  if next_status='approved' and local_row.status<>'approved' then
    select * into plan_row from public.plans where code=local_row.plan_code and active=true;
    if not found or plan_row.price_cents<>p_amount_cents then
      raise exception 'plan_amount_mismatch';
    end if;
    select * into current_row from public.subscriptions
    where user_id=local_row.user_id and status in ('active','trialing') and current_period_end>now()
    order by created_at desc limit 1 for update;

    if found and current_row.plan_code=local_row.plan_code then
      period_start := greatest(now(),current_row.current_period_end);
    else
      period_start := now();
    end if;
    period_end := period_start + make_interval(days => plan_row.duration_days);

    update public.subscriptions set status='expired',updated_at=now()
    where user_id=local_row.user_id and status in ('active','trialing');

    insert into public.subscriptions(user_id,plan_code,status,started_at,current_period_start,current_period_end,payment_id)
    values (local_row.user_id,local_row.plan_code,'active',period_start,period_start,period_end,local_row.id);

    insert into public.platform_events(user_id,event_type,payload)
    values (local_row.user_id,'subscription.activated',jsonb_build_object('plan_code',local_row.plan_code,'payment_id',local_row.id));
  elsif next_status in ('refunded','chargeback') then
    update public.subscriptions set status='expired',updated_at=now()
    where payment_id=local_row.id and status in ('active','trialing');
    insert into public.platform_events(user_id,event_type,payload)
    values (local_row.user_id,'payment.'||next_status,jsonb_build_object('payment_id',local_row.id));
  end if;

  return jsonb_build_object('ok',true,'duplicate',false,'status',next_status);
end;
$$;

revoke all on function public.process_mercadopago_payment(text,text,text,integer,integer,integer,text,text,timestamptz,text,text,jsonb) from public,anon,authenticated;
grant execute on function public.process_mercadopago_payment(text,text,text,integer,integer,integer,text,text,timestamptz,text,text,jsonb) to service_role;

grant all on all tables in schema public to service_role;
grant all on all sequences in schema public to service_role;
revoke select on public.websites from anon;
grant select(name,content,slug,status,published_at) on public.websites to anon;

-- Adiciona as tabelas relevantes ao Realtime quando a publicação existir.
do $$
declare
  table_name text;
begin
  if exists (select 1 from pg_publication where pubname='supabase_realtime') then
    foreach table_name in array array['profiles','websites','payments','subscriptions','user_sessions'] loop
      begin
        execute format('alter publication supabase_realtime add table public.%I', table_name);
      exception when duplicate_object then
        null;
      end;
    end loop;
  end if;
end;
$$;
