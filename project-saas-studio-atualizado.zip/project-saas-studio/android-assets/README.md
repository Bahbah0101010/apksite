# Recursos de ícone Android

Os PNGs desta pasta foram derivados da fotografia quadrada fornecida, sem trocar ou retocar a imagem:
- mipmap-* contém ícones legados por densidade;
- mipmap-anydpi-v26 contém ícones adaptativos;
- drawable contém foreground e background adaptativos.

Quando o projeto Android for materializado com `npx cap add android`, copie o conteúdo de
`android-assets/app/src/main/res/` para `android/app/src/main/res/` (mesclando as pastas).
Em seguida execute `npx cap sync android` e confira o ícone em um emulador/aparelho.
A compilação/instalação ainda depende de Android SDK, JDK e Gradle.
