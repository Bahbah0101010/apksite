import { createHmac, timingSafeEqual } from "node:crypto";

export async function createCheckoutPreference(input: {
  externalReference: string;
  title: string;
  amount: number;
  payerEmail: string;
  backUrl: string;
  notificationUrl: string;
}) {
  const token = process.env.MERCADOPAGO_ACCESS_TOKEN;
  if (!token) throw new Error("MERCADOPAGO_ACCESS_TOKEN não configurado.");

  const response = await fetch("https://api.mercadopago.com/checkout/preferences", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${token}`,
      "Content-Type": "application/json",
      "X-Idempotency-Key": input.externalReference,
    },
    body: JSON.stringify({
      items: [{
        id: input.externalReference,
        title: input.title,
        quantity: 1,
        currency_id: "BRL",
        unit_price: input.amount,
      }],
      payer: { email: input.payerEmail },
      external_reference: input.externalReference,
      notification_url: input.notificationUrl,
      back_urls: {
        success: `${input.backUrl}/app/assinatura?result=success`,
        pending: `${input.backUrl}/app/assinatura?result=pending`,
        failure: `${input.backUrl}/app/assinatura?result=failure`,
      },
      auto_return: "approved",
      statement_descriptor: "STUDIO SAAS",
      payment_methods: {
        installments: 1,
      },
    }),
    cache: "no-store",
  });

  const data = await response.json().catch(() => ({}));
  if (!response.ok || !data.id || !data.init_point) {
    throw new Error(data.message ?? "O Mercado Pago não criou o checkout.");
  }
  return {
    preferenceId: String(data.id),
    checkoutUrl: process.env.MERCADOPAGO_ENV === "production"
      ? String(data.init_point)
      : String(data.sandbox_init_point ?? data.init_point),
  };
}

export function validateMercadoPagoSignature(input: {
  signature: string | null;
  requestId: string | null;
  dataId: string;
  secret: string;
}) {
  if (!input.signature || !input.requestId || !input.dataId || !input.secret) return false;
  const fields = Object.fromEntries(
    input.signature.split(",").map((part) => {
      const [key, ...rest] = part.trim().split("=");
      return [key, rest.join("=")];
    }),
  );
  const ts = fields.ts;
  const v1 = fields.v1;
  if (!ts || !v1) return false;

  const manifest = `id:${input.dataId.toLowerCase()};request-id:${input.requestId};ts:${ts};`;
  const expected = createHmac("sha256", input.secret).update(manifest).digest("hex");
  try {
    const a = Buffer.from(expected, "hex");
    const b = Buffer.from(v1, "hex");
    return a.length === b.length && timingSafeEqual(a, b);
  } catch {
    return false;
  }
}
