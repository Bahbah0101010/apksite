export const PLANS = {
  free: {
    code: "free",
    name: "Free",
    priceCents: 0,
    billing: "30 dias",
    durationDays: 30,
    dailyLimit: 10,
    summary: "Para conhecer o editor e colocar a primeira ideia no papel.",
    features: ["10 gerações por dia", "Modelos gratuitos", "Editor básico", "SEO básico", "Projetos salvos"],
  },
  professional: {
    code: "professional",
    name: "Professional",
    priceCents: 9700,
    billing: "por mês",
    durationDays: 30,
    dailyLimit: 30,
    summary: "Mais controle para negócios que precisam de presença constante.",
    features: ["30 gerações por dia", "Modelos premium", "Editor completo", "Publicação de sites", "Estatísticas de acesso", "Suporte prioritário"],
  },
  business: {
    code: "business",
    name: "Business",
    priceCents: 69700,
    billing: "por ano",
    durationDays: 365,
    dailyLimit: 100,
    summary: "Uma estrutura ampla para vários negócios e projetos.",
    features: ["100 gerações por dia", "Todos os modelos", "Vários negócios", "Estatísticas avançadas", "Editor completo", "Suporte prioritário"],
  },
} as const;

export type PlanCode = keyof typeof PLANS;

export function getPlan(code: string) {
  return Object.prototype.hasOwnProperty.call(PLANS, code)
    ? PLANS[code as PlanCode]
    : PLANS.free;
}

export function formatBRL(cents: number) {
  return new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(cents / 100);
}

export function hasPublishingEntitlement(input: {
  planCode: string;
  status: string;
  currentPeriodEnd: string | null;
  now?: Date;
}) {
  if (!["professional", "business"].includes(input.planCode)) return false;
  if (!["active", "trialing"].includes(input.status) || !input.currentPeriodEnd) return false;
  const end = new Date(input.currentPeriodEnd);
  const now = input.now ?? new Date();
  return !Number.isNaN(end.getTime()) && end > now;
}
