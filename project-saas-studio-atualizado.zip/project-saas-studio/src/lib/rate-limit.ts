import { createSupabaseAdminClient } from "@/lib/supabase/admin";

export type UserRateLimitDecision =
  | { available: false; allowed: false; retryAfterSeconds: number }
  | { available: true; allowed: boolean; retryAfterSeconds: number; remaining: number };

/**
 * Consome um limite atômico no PostgreSQL. Falha fechada quando o RPC
 * não responde, para não transformar indisponibilidade do controle em bypass.
 */
export async function checkUserRateLimit(
  userId: string,
  scope: string,
  limit: number,
  windowSeconds: number,
): Promise<UserRateLimitDecision> {
  let admin: ReturnType<typeof createSupabaseAdminClient>;
  try {
    admin = createSupabaseAdminClient();
  } catch {
    return { available: false, allowed: false, retryAfterSeconds: windowSeconds };
  }
  const { data, error } = await admin.rpc("consume_user_rate_limit", {
    p_user_id: userId,
    p_scope: scope,
    p_limit: limit,
    p_window_seconds: windowSeconds,
  });
  if (error || !data || typeof data !== "object") {
    return { available: false, allowed: false, retryAfterSeconds: windowSeconds };
  }

  const result = data as { allowed?: unknown; remaining?: unknown; retry_after_seconds?: unknown };
  return {
    available: true,
    allowed: result.allowed === true,
    remaining: typeof result.remaining === "number" ? result.remaining : 0,
    retryAfterSeconds: typeof result.retry_after_seconds === "number" ? result.retry_after_seconds : windowSeconds,
  };
}
