export const brand = {
  name: "Studio",
  descriptor: "Sites para negócios reais",
  appId: "com.projectsaas.studio",
};
