"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { createSupabaseBrowserClient } from "@/lib/supabase/browser";
import { formatBRL } from "@/lib/plans";

interface Metrics {
  accounts: { total: number; new_24h: number };
  presence: { accounts_online: number; sessions_online: number };
  traffic: { views_24h: number; unique_visitors_24h: number; sessions_24h: number };
  sites: { total: number; published: number };
  subscriptions: { free: number; professional: number; business: number; total: number };
  payments: { approved: number; pending: number; rejected: number; refunded: number; gross_cents: number; fee_cents: number; refunded_cents: number; net_cents: number | null };
  series: Array<{ day: string; signups: number; views: number; payments: number; revenue_cents: number }>;
  online_definition: string;
  generation_usage: {
    successful_today: number;
    reserved_today: number;
    active_generators_today: number;
    successful_7d: number;
    daily: Array<{ day: string; successful: number; reserved: number }>;
  };
}

export function AdminDashboard() {
  const [metrics, setMetrics] = useState<Metrics | null>(null);
  const [updatedAt, setUpdatedAt] = useState<string | null>(null);
  const [connection, setConnection] = useState<"loading" | "connected" | "reconnecting" | "offline">("loading");
  const [error, setError] = useState("");

  const refresh = useCallback(async () => {
    try {
      setConnection((current) => current === "connected" ? "reconnecting" : "loading");
      const response = await fetch("/api/admin/metrics", { cache: "no-store" });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error ?? "Falha ao atualizar indicadores.");
      setMetrics(result.data); setUpdatedAt(result.updatedAt); setError(""); setConnection("connected");
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "Não foi possível consultar o servidor.");
      setConnection("offline");
    }
  }, []);

  useEffect(() => {
    void refresh();
    const supabase = createSupabaseBrowserClient();
    const channel = supabase.channel("studio-admin-live")
      .on("postgres_changes", { event: "*", schema: "public", table: "profiles" }, () => void refresh())
      .on("postgres_changes", { event: "*", schema: "public", table: "websites" }, () => void refresh())
      .on("postgres_changes", { event: "*", schema: "public", table: "payments" }, () => void refresh())
      .on("postgres_changes", { event: "*", schema: "public", table: "subscriptions" }, () => void refresh())
      .on("postgres_changes", { event: "*", schema: "public", table: "user_sessions" }, () => void refresh())
      .subscribe((status) => {
        if (status === "SUBSCRIBED") setConnection((current) => current === "offline" ? "connected" : current);
        if (status === "CHANNEL_ERROR" || status === "TIMED_OUT" || status === "CLOSED") setConnection("reconnecting");
      });
    const poll = window.setInterval(() => void refresh(), 30000);
    return () => { window.clearInterval(poll); void supabase.removeChannel(channel); };
  }, [refresh]);

  const chartMax = useMemo(() => Math.max(1, ...(metrics?.series.map((day) => day.views) ?? [1])), [metrics]);
  const lastLabel = updatedAt ? new Intl.DateTimeFormat("pt-BR", { timeStyle: "medium", timeZone: "America/Sao_Paulo" }).format(new Date(updatedAt)) : "—";
  const money = metrics?.payments.net_cents === null ? "Indisponível" : metrics ? formatBRL(metrics.payments.net_cents) : "—";

  return <>
    <div className="app-topbar"><div><h1>Visão administrativa</h1><p>Indicadores consultados no banco de dados, sem números de demonstração.</p></div><div className="admin-toolbar"><span className={`connection-dot ${connection === "connected" ? "connected" : ""}`} />{connection === "connected" ? "Conectado" : connection === "loading" ? "Carregando" : connection === "reconnecting" ? "Reconectando" : "Desconectado"}<button className="button secondary" onClick={() => void refresh()} style={{ minHeight: 34, padding: "0 11px" }}>Atualizar</button></div></div>
    <p style={{ color: "var(--muted)", fontSize: 10, margin: "-20px 0 20px" }}>Última atualização válida: {lastLabel}. A presença considera heartbeat nos últimos 90 segundos.</p>
    {error && <div className="form-error" role="alert">{error} Os dados exibidos podem estar desatualizados.</div>}
    {!metrics && !error && <div className="panel"><div className="empty-state">Carregando informações reais…</div></div>}
    {metrics && <>
      <div className="metric-grid">
        <article className="metric-card"><span>Contas cadastradas</span><strong>{metrics.accounts.total.toLocaleString("pt-BR")}</strong></article>
        <article className="metric-card"><span>Novas contas · 24h</span><strong>{metrics.accounts.new_24h.toLocaleString("pt-BR")}</strong></article>
        <article className="metric-card"><span>Contas online agora</span><strong>{metrics.presence.accounts_online.toLocaleString("pt-BR")}</strong></article>
        <article className="metric-card"><span>Sessões autenticadas online</span><strong>{metrics.presence.sessions_online.toLocaleString("pt-BR")}</strong></article>
        <article className="metric-card"><span>Visitantes únicos estimados · 24h</span><strong>{metrics.traffic.unique_visitors_24h.toLocaleString("pt-BR")}</strong></article>
        <article className="metric-card"><span>Visualizações · 24h</span><strong>{metrics.traffic.views_24h.toLocaleString("pt-BR")}</strong></article>
        <article className="metric-card"><span>Sites cadastrados</span><strong>{metrics.sites.total.toLocaleString("pt-BR")}</strong></article>
        <article className="metric-card"><span>Sites publicados</span><strong>{metrics.sites.published.toLocaleString("pt-BR")}</strong></article>
        <article className="metric-card"><span>Gerações concluídas hoje</span><strong>{metrics.generation_usage.successful_today.toLocaleString("pt-BR")}</strong></article>
        <article className="metric-card"><span>Contas que geraram hoje</span><strong>{metrics.generation_usage.active_generators_today.toLocaleString("pt-BR")}</strong></article>
        <article className="metric-card"><span>Reservas em processamento</span><strong>{metrics.generation_usage.reserved_today.toLocaleString("pt-BR")}</strong></article>
        <article className="metric-card"><span>Gerações concluídas · 7 dias</span><strong>{metrics.generation_usage.successful_7d.toLocaleString("pt-BR")}</strong></article>
      </div>
      <section className="panel"><div className="panel-head"><div><h2>Planos ativos</h2><p>Contas com período vigente no banco de dados.</p></div></div><div className="metric-grid" style={{ marginBottom: 0 }}><article className="metric-card"><span>Free</span><strong>{metrics.subscriptions.free}</strong></article><article className="metric-card"><span>Professional</span><strong>{metrics.subscriptions.professional}</strong></article><article className="metric-card"><span>Business</span><strong>{metrics.subscriptions.business}</strong></article><article className="metric-card"><span>Total ativos</span><strong>{metrics.subscriptions.total}</strong></article></div></section>
      <section className="panel"><div className="panel-head"><div><h2>Financeiro de produção</h2><p>Pagamentos com modo live. Transações de teste ficam fora destes valores.</p></div></div><div className="metric-grid" style={{ marginBottom: 0 }}><article className="metric-card"><span>Pagamentos aprovados</span><strong>{metrics.payments.approved}</strong></article><article className="metric-card"><span>Pagamentos pendentes</span><strong>{metrics.payments.pending}</strong></article><article className="metric-card"><span>Recusados</span><strong>{metrics.payments.rejected}</strong></article><article className="metric-card"><span>Reembolsos / chargebacks</span><strong>{metrics.payments.refunded}</strong></article><article className="metric-card"><span>Faturamento bruto</span><strong style={{ fontSize: 22 }}>{formatBRL(metrics.payments.gross_cents)}</strong></article><article className="metric-card"><span>Taxas registradas</span><strong style={{ fontSize: 22 }}>{formatBRL(metrics.payments.fee_cents)}</strong></article><article className="metric-card"><span>Estornos</span><strong style={{ fontSize: 22 }}>{formatBRL(metrics.payments.refunded_cents)}</strong></article><article className="metric-card"><span>Receita líquida calculável</span><strong style={{ fontSize: 22 }}>{money}</strong></article></div></section>
      <section className="panel"><div className="panel-head"><div><h2>Atividade dos últimos 7 dias</h2><p>Visualizações reais por dia, sem preenchimento artificial.</p></div></div>
        {metrics.series.length === 0 ? <div className="empty-state">Ainda não há dados para este período.</div> : <><div className="chart">{metrics.series.map((day) => <div key={day.day} className="chart-bar" title={`${day.day}: ${day.views} visualizações`} style={{ height: `${Math.max(2, (day.views / chartMax) * 100)}%` }} />)}</div><div className="chart-labels">{metrics.series.map((day) => <span key={day.day}>{new Date(`${day.day}T12:00:00`).toLocaleDateString("pt-BR", { day: "2-digit", month: "2-digit" })}</span>)}</div></>}
      </section>
      <section className="panel"><div className="panel-head"><div><h2>Consumo de IA · últimos 7 dias</h2><p>Gerações concluídas e reservas ainda em andamento, contabilizadas no PostgreSQL.</p></div></div>
        {metrics.generation_usage.daily.length === 0 ? <div className="empty-state">Ainda não há dados de consumo neste período.</div> : <div className="table-wrap"><table><thead><tr><th>Dia</th><th>Concluídas</th><th>Reservadas</th></tr></thead><tbody>{metrics.generation_usage.daily.map((day) => <tr key={day.day}><td>{new Date(`${day.day}T12:00:00`).toLocaleDateString("pt-BR", { timeZone: "America/Sao_Paulo" })}</td><td>{day.successful.toLocaleString("pt-BR")}</td><td>{day.reserved.toLocaleString("pt-BR")}</td></tr>)}</tbody></table></div>}
      </section>
      <section className="panel"><div className="panel-head"><div><h2>Definições de medição</h2><p>O painel diferencia navegador, sessão e conta autenticada.</p></div></div><p style={{ fontSize: 11, color: "var(--muted)" }}>{metrics.online_definition}</p><p style={{ fontSize: 11, color: "var(--muted)" }}>Visitantes únicos são estimativas baseadas em identificadores pseudonimizados e consentimento de analytics. Não representam necessariamente pessoas físicas distintas. Visualizações são eventos de página e não devem ser interpretadas como visitantes.</p></section>
    </>}
  </>;
}
