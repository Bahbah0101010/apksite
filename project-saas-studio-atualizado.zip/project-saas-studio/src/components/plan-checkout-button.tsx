"use client";

import { useState } from "react";

export function PlanCheckoutButton({ planCode, label }: { planCode: "professional" | "business"; label: string }) {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  async function checkout() {
    setBusy(true); setError("");
    try {
      const response = await fetch("/api/payments/checkout", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ planCode }),
      });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error ?? "Não foi possível iniciar o pagamento.");
      window.location.assign(result.checkoutUrl);
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "Erro ao iniciar checkout.");
      setBusy(false);
    }
  }
  return <div><button className="button" onClick={checkout} disabled={busy}>{busy ? "Abrindo checkout…" : label}</button>{error && <p className="form-error">{error}</p>}</div>;
}
