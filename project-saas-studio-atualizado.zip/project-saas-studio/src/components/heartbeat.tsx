"use client";

import { useEffect } from "react";
import { usePathname } from "next/navigation";

export function Heartbeat() {
  useEffect(() => {
    let sessionId = sessionStorage.getItem("studio-session-id");
    if (!sessionId) { sessionId = crypto.randomUUID(); sessionStorage.setItem("studio-session-id", sessionId); }
    const send = () => {
      void fetch("/api/presence/heartbeat", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ sessionId, page: window.location.pathname }), keepalive: true,
      }).catch(() => undefined);
    };
    send();
    const timer = window.setInterval(send, 30000);
    const onVisible = () => { if (document.visibilityState === "visible") send(); };
    document.addEventListener("visibilitychange", onVisible);
    return () => { window.clearInterval(timer); document.removeEventListener("visibilitychange", onVisible); };
  }, []);
  return null;
}

export function AnalyticsTracker() {
  const pathname = usePathname();
  useEffect(() => {
    const track = () => {
      if (localStorage.getItem("studio-analytics-consent") !== "yes") return;
      let sessionId = sessionStorage.getItem("studio-analytics-session");
      if (!sessionId) { sessionId = crypto.randomUUID(); sessionStorage.setItem("studio-analytics-session", sessionId); }
      void fetch("/api/analytics/track", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ path: pathname || "/", referrer: document.referrer || null, sessionId }),
        keepalive: true,
      }).catch(() => undefined);
    };
    track();
    window.addEventListener("studio-consent-change", track);
    return () => window.removeEventListener("studio-consent-change", track);
  }, [pathname]);
  return null;
}
