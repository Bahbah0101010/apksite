"use client";

import { useEffect, useState } from "react";

export function CookieConsent() {
  const [visible, setVisible] = useState(false);
  useEffect(() => { setVisible(localStorage.getItem("studio-analytics-consent") === null); }, []);
  function choose(value: "yes" | "no") {
    localStorage.setItem("studio-analytics-consent", value);
    document.cookie = `studio_analytics_consent=${value}; path=/; max-age=31536000; samesite=lax`;
    window.dispatchEvent(new Event("studio-consent-change"));
    setVisible(false);
  }
  if (!visible) return null;
  return <div className="cookie-box" role="dialog" aria-label="Preferência de analytics">
    <strong style={{ font: "19px Georgia, serif" }}>Sua privacidade importa.</strong>
    <p>O analytics opcional registra visualizações e sessões pseudonimizadas para medir o uso da plataforma. Você pode aceitar ou recusar.</p>
    <div className="cookie-actions"><button className="primary" onClick={() => choose("yes")}>Aceitar analytics</button><button onClick={() => choose("no")}>Recusar</button></div>
  </div>;
}
