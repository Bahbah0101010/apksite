"use client";

import { useState, type FormEvent } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { createSupabaseBrowserClient } from "@/lib/supabase/browser";

export function AuthForm({ mode }: { mode: "login" | "signup" | "reset" }) {
  const router = useRouter();
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [recovering, setRecovering] = useState(false);

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setBusy(true); setError(""); setSuccess("");
    try {
      const supabase = createSupabaseBrowserClient();
      if (mode === "reset") {
        const { error: updateError } = await supabase.auth.updateUser({ password });
        if (updateError) throw updateError;
        setSuccess("Senha atualizada. Você já pode entrar com a nova senha.");
        setPassword("");
        router.replace("/login");
        router.refresh();
      } else if (mode === "signup") {
        const { data, error: authError } = await supabase.auth.signUp({
          email: email.trim(),
          password,
          options: { data: { full_name: name.trim() }, emailRedirectTo: `${window.location.origin}/login` },
        });
        if (authError) throw authError;
        if (!data.session) setSuccess("Cadastro enviado. Confirme o endereço de e-mail para entrar.");
        else { router.replace("/app"); router.refresh(); }
      } else if (recovering) {
        const { error: resetError } = await supabase.auth.resetPasswordForEmail(email.trim(), {
          redirectTo: `${window.location.origin}/reset-password`,
        });
        if (resetError) throw resetError;
        setSuccess("Se o endereço estiver cadastrado, você receberá um link para redefinir a senha.");
        setRecovering(false);
      } else {
        const { error: authError } = await supabase.auth.signInWithPassword({ email: email.trim(), password });
        if (authError) throw authError;
        router.replace("/app"); router.refresh();
      }
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "Não foi possível concluir. Tente novamente.");
    } finally { setBusy(false); }
  }

  const isRecoveryRequest = mode === "login" && recovering;
  return <form onSubmit={submit}>
    {mode === "signup" && <div className="field"><label htmlFor="name">Seu nome</label><input id="name" autoComplete="name" required minLength={2} value={name} onChange={(e) => setName(e.target.value)} /></div>}
    {(mode !== "reset") && <div className="field"><label htmlFor="email">E-mail</label><input id="email" type="email" autoComplete="email" required value={email} onChange={(e) => setEmail(e.target.value)} /></div>}
    {mode === "reset" && <div className="field"><label htmlFor="password">Nova senha</label><input id="password" type="password" autoComplete="new-password" minLength={8} required value={password} onChange={(e) => setPassword(e.target.value)} /></div>}
    {mode === "signup" && <div className="field"><label htmlFor="password">Senha</label><input id="password" type="password" autoComplete="new-password" minLength={8} required value={password} onChange={(e) => setPassword(e.target.value)} /></div>}
    {mode === "login" && !recovering && <div className="field"><label htmlFor="password">Senha</label><input id="password" type="password" autoComplete="current-password" minLength={8} required value={password} onChange={(e) => setPassword(e.target.value)} /></div>}
    {error && <div className="form-error" role="alert">{error}</div>}
    {success && <div className="form-success" role="status">{success}</div>}
    <button className="button" type="submit" disabled={busy} style={{ width: "100%", marginTop: 5 }}>
      {busy ? "Aguarde…" : mode === "signup" ? "Criar conta" : mode === "reset" ? "Atualizar senha" : isRecoveryRequest ? "Enviar link de recuperação" : "Entrar"}
    </button>
    {mode === "login" && <button type="button" className="text-link" style={{ border: 0, background: "transparent", marginTop: 14, padding: 0 }} onClick={() => { setRecovering((value) => !value); setError(""); setSuccess(""); }}>
      {recovering ? "Voltar ao login" : "Esqueci minha senha"}
    </button>}
    {mode !== "reset" && <div className="auth-footnote">{mode === "signup" ? <>Já tem uma conta? <Link className="text-link" href="/login">Entrar</Link></> : <>Ainda não tem uma conta? <Link className="text-link" href="/signup">Criar conta</Link></>}</div>}
    {mode === "reset" && <div className="auth-footnote"><Link className="text-link" href="/login">Voltar para entrar</Link></div>}
  </form>;
}
