"use client";

import { useState, type FormEvent } from "react";
import { useRouter } from "next/navigation";

export function SiteGenerator() {
  const router = useRouter();
  const [name, setName] = useState("");
  const [category, setCategory] = useState("servicos");
  const [description, setDescription] = useState("");
  const [city, setCity] = useState("");
  const [address, setAddress] = useState("");
  const [phone, setPhone] = useState("");
  const [whatsapp, setWhatsapp] = useState("");
  const [email, setEmail] = useState("");
  const [products, setProducts] = useState("");
  const [services, setServices] = useState("");
  const [style, setStyle] = useState("editorial e acolhedor");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  async function generate(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setBusy(true); setError("");
    try {
      const response = await fetch("/api/ai/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name, category, description, city: city || null, address: address || null,
          phone: phone || null, whatsapp: whatsapp || null, email: email || null,
          products: products || null, services: services || null, style,
        }),
      });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error ?? "Não foi possível gerar o site.");
      router.push(`/app/sites/${result.website.id}`);
      router.refresh();
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "Falha inesperada ao gerar o site.");
    } finally { setBusy(false); }
  }

  return <form onSubmit={generate} className="panel">
    <div className="panel-head"><div><h2>Conte sobre o negócio</h2><p>A IA organiza os dados recebidos sem criar informações comerciais ausentes.</p></div></div>
    <div className="form-grid">
      <div className="field"><label htmlFor="business-name">Nome do negócio *</label><input id="business-name" required minLength={2} maxLength={80} value={name} onChange={(e) => setName(e.target.value)} placeholder="Nome comercial" /></div>
      <div className="field"><label htmlFor="category">Categoria *</label><select id="category" value={category} onChange={(e) => setCategory(e.target.value)}><option value="servicos">Prestação de serviços</option><option value="barbearia">Barbearia</option><option value="restaurante">Restaurante</option><option value="lanchonete">Lanchonete</option><option value="loja">Loja</option><option value="beleza">Salão de beleza</option><option value="oficina">Oficina</option><option value="academia">Academia</option><option value="profissional">Profissional autônomo</option></select></div>
      <div className="field full"><label htmlFor="description">Descrição do negócio *</label><textarea id="description" required minLength={15} maxLength={1600} value={description} onChange={(e) => setDescription(e.target.value)} placeholder="Explique o que oferece, a quem atende e informações que precisam aparecer no site." /></div>
      <div className="field"><label htmlFor="city">Cidade</label><input id="city" maxLength={90} value={city} onChange={(e) => setCity(e.target.value)} placeholder="Cidade e estado" /></div>
      <div className="field"><label htmlFor="address">Endereço</label><input id="address" maxLength={220} value={address} onChange={(e) => setAddress(e.target.value)} /></div>
      <div className="field"><label htmlFor="phone">Telefone</label><input id="phone" maxLength={32} value={phone} onChange={(e) => setPhone(e.target.value)} /></div>
      <div className="field"><label htmlFor="whatsapp">WhatsApp comercial</label><input id="whatsapp" maxLength={32} value={whatsapp} onChange={(e) => setWhatsapp(e.target.value)} /></div>
      <div className="field"><label htmlFor="email">E-mail comercial</label><input id="email" type="email" maxLength={160} value={email} onChange={(e) => setEmail(e.target.value)} /></div>
      <div className="field full"><label htmlFor="products">Produtos e preços (opcional)</label><textarea id="products" maxLength={3000} value={products} onChange={(e) => setProducts(e.target.value)} placeholder={"Um item por linha: Nome | descrição | preço\nEx.: Café especial | Pacote de 250 g | R$ 32,00"} /></div>
      <div className="field full"><label htmlFor="services">Serviços (opcional)</label><textarea id="services" maxLength={3000} value={services} onChange={(e) => setServices(e.target.value)} placeholder="Um serviço por linha. Não inclua preços ou detalhes que ainda não estejam definidos." /></div>
      <div className="field full"><label htmlFor="style">Direção visual</label><select id="style" value={style} onChange={(e) => setStyle(e.target.value)}><option>editorial e acolhedor</option><option>minimalista e elegante</option><option>leve e contemporâneo</option><option>clássico e institucional</option><option>vibrante e comercial</option></select></div>
    </div>
    {error && <div className="form-error" role="alert">{error}</div>}
    <button className="button" type="submit" disabled={busy}>{busy ? "Preparando estrutura…" : "Gerar estrutura do site"}</button>
    <p style={{ fontSize: 10, color: "var(--muted)", marginBottom: 0 }}>Imagens e logotipo podem ser enviados depois no editor. A geração depende do provedor de IA configurado no servidor e só consome cota após ser salva com sucesso.</p>
  </form>;
}
