import Link from "next/link";
import { Brand } from "@/components/brand";

export function SiteHeader() {
  return <header className="site-header"><div className="container header-inner">
    <Brand />
    <nav className="nav" aria-label="Navegação principal">
      <Link href="#recursos">Recursos</Link><Link href="#como-funciona">Como funciona</Link><Link href="#planos">Planos</Link>
    </nav>
    <div className="header-actions"><Link className="button secondary" href="/login">Entrar</Link><Link className="button" href="/signup">Criar conta</Link></div>
  </div></header>;
}
