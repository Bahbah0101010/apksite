/* eslint-disable @next/next/no-img-element */
"use client";

import { useEffect, useMemo, useRef, useState, type CSSProperties } from "react";
import { createSupabaseBrowserClient } from "@/lib/supabase/browser";

export type WebsiteSection = {
  heading: string;
  body: string;
  imageUrl?: string;
  buttonLabel?: string;
  buttonUrl?: string;
};

export type WebsiteProduct = {
  id: string;
  name: string;
  description: string;
  price: string;
  imageUrl: string;
};

export type WebsiteContent = {
  title: string;
  subtitle: string;
  about: string;
  contact: string;
  accent: string;
  sections: WebsiteSection[];
  products: WebsiteProduct[];
  logoUrl?: string;
  heroImageUrl?: string;
  contactEmail?: string;
  phone?: string;
  address?: string;
  buttonLabel?: string;
  buttonUrl?: string;
  footer?: string;
  fontFamily?: "serif" | "sans";
  business?: { city?: string; address?: string; category?: string };
  visualStyle?: string;
};

type PreviewDevice = "mobile" | "tablet" | "desktop";

function isSafeImageUrl(value: string) {
  return value.startsWith("https://") && value.length < 2000;
}

function normalizeContent(raw: unknown, fallbackTitle: string): WebsiteContent {
  const value = raw && typeof raw === "object" ? raw as Partial<WebsiteContent> : {};
  const sections = Array.isArray(value.sections) ? value.sections.slice(0, 10).map((section) => ({
    heading: typeof section?.heading === "string" ? section.heading : "",
    body: typeof section?.body === "string" ? section.body : "",
    imageUrl: typeof section?.imageUrl === "string" ? section.imageUrl : "",
    buttonLabel: typeof section?.buttonLabel === "string" ? section.buttonLabel : "",
    buttonUrl: typeof section?.buttonUrl === "string" ? section.buttonUrl : "",
  })) : [];
  const products = Array.isArray(value.products) ? value.products.slice(0, 24).map((product) => ({
    id: typeof product?.id === "string" ? product.id : crypto.randomUUID(),
    name: typeof product?.name === "string" ? product.name : "",
    description: typeof product?.description === "string" ? product.description : "",
    price: typeof product?.price === "string" ? product.price : "",
    imageUrl: typeof product?.imageUrl === "string" ? product.imageUrl : "",
  })) : [];
  return {
    title: typeof value.title === "string" ? value.title : fallbackTitle,
    subtitle: typeof value.subtitle === "string" ? value.subtitle : "",
    about: typeof value.about === "string" ? value.about : "",
    contact: typeof value.contact === "string" ? value.contact : "",
    accent: typeof value.accent === "string" && /^#[0-9a-fA-F]{6}$/.test(value.accent) ? value.accent : "#8f685e",
    sections,
    products,
    logoUrl: typeof value.logoUrl === "string" ? value.logoUrl : "",
    heroImageUrl: typeof value.heroImageUrl === "string" ? value.heroImageUrl : "",
    contactEmail: typeof value.contactEmail === "string" ? value.contactEmail : "",
    phone: typeof value.phone === "string" ? value.phone : "",
    address: typeof value.address === "string" ? value.address : "",
    buttonLabel: typeof value.buttonLabel === "string" ? value.buttonLabel : "",
    buttonUrl: typeof value.buttonUrl === "string" ? value.buttonUrl : "",
    footer: typeof value.footer === "string" ? value.footer : "",
    fontFamily: value.fontFamily === "sans" ? "sans" : "serif",
    business: {
      city: typeof value.business?.city === "string" ? value.business.city : "",
      address: typeof value.business?.address === "string" ? value.business.address : "",
      category: typeof value.business?.category === "string" ? value.business.category : "",
    },
    visualStyle: typeof value.visualStyle === "string" ? value.visualStyle : "",
  };
}

export function WebsiteEditor({ websiteId, initialName, initialContent, initialStatus, publishedUrl }: {
  websiteId: string;
  initialName: string;
  initialContent: WebsiteContent;
  initialStatus: string;
  publishedUrl: string | null;
}) {
  const [name, setName] = useState(initialName);
  const [content, setContent] = useState<WebsiteContent>(initialContent);
  const [status, setStatus] = useState(initialStatus);
  const [busy, setBusy] = useState(false);
  const [uploading, setUploading] = useState("");
  const [message, setMessage] = useState("");
  const [autoState, setAutoState] = useState<"ready" | "saving" | "saved" | "error">("ready");
  const [previewDevice, setPreviewDevice] = useState<PreviewDevice>("desktop");
  const [history, setHistory] = useState<Array<{ id: string; created_at: string; name: string; content: WebsiteContent }>>([]);
  const [historyOpen, setHistoryOpen] = useState(false);
  const firstRender = useRef(true);
  const preview = useMemo(() => content, [content]);

  useEffect(() => {
    if (firstRender.current) { firstRender.current = false; return; }
    const controller = new AbortController();
    const timer = window.setTimeout(async () => {
      setAutoState("saving");
      try {
        const response = await fetch(`/api/websites/${websiteId}`, {
          method: "PATCH",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ name, content }),
          signal: controller.signal,
        });
        if (!response.ok) throw new Error("Não foi possível salvar automaticamente.");
        setAutoState("saved");
      } catch (error) {
        if (!(error instanceof DOMException && error.name === "AbortError")) setAutoState("error");
      }
    }, 1000);
    return () => { window.clearTimeout(timer); controller.abort(); };
  }, [name, content, websiteId]);

  async function save(): Promise<boolean> {
    setBusy(true); setMessage("");
    try {
      const response = await fetch(`/api/websites/${websiteId}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, content }),
      });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error ?? "Falha ao salvar.");
      setMessage("Alterações salvas com segurança.");
      setAutoState("saved");
      return true;
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "Não foi possível salvar.");
      setAutoState("error");
      return false;
    } finally { setBusy(false); }
  }

  async function publish() {
    const saved = await save();
    if (!saved) return;
    setBusy(true); setMessage("");
    try {
      const response = await fetch(`/api/websites/${websiteId}/publish`, { method: "POST" });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error ?? "Falha ao publicar.");
      setStatus(result.website.status);
      setMessage(result.warning ? `${result.warning} Endereço: ${result.url}` : `Site publicado: ${result.url}`);
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "Não foi possível publicar.");
    } finally { setBusy(false); }
  }

  async function unpublish() {
    setBusy(true); setMessage("");
    try {
      const response = await fetch(`/api/websites/${websiteId}/unpublish`, { method: "POST" });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error ?? "Falha ao despublicar.");
      setStatus(result.website.status);
      setMessage(result.warning ?? "Site despublicado. O endereço público não está mais disponível.");
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "Não foi possível despublicar.");
    } finally { setBusy(false); }
  }

  async function loadHistory() {
    setHistoryOpen((value) => !value);
    if (history.length) return;
    const response = await fetch(`/api/websites/${websiteId}/revisions`, { cache: "no-store" });
    const result = await response.json();
    if (!response.ok) { setMessage(result.error ?? "Não foi possível carregar o histórico."); return; }
    setHistory(result.revisions ?? []);
  }

  async function restoreRevision(revisionId: string) {
    setBusy(true); setMessage("");
    try {
      const response = await fetch(`/api/websites/${websiteId}/revisions/${revisionId}/restore`, { method: "POST" });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error ?? "Não foi possível restaurar a versão.");
      setName(result.website.name);
      setContent(normalizeContent(result.website.content, result.website.name));
      setHistory([]);
      setHistoryOpen(false);
      setMessage("Versão restaurada. O estado anterior foi preservado no histórico.");
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "Falha ao restaurar a versão.");
    } finally { setBusy(false); }
  }

  async function uploadImage(file: File, field: string) {
    if (!["image/jpeg", "image/png", "image/webp"].includes(file.type) || file.size > 8 * 1024 * 1024) {
      setMessage("Use uma imagem JPG, PNG ou WebP de até 8 MB.");
      return;
    }
    setUploading(field);
    setMessage("");
    try {
      const supabase = createSupabaseBrowserClient();
      const extension = file.type === "image/jpeg" ? "jpg" : file.type === "image/png" ? "png" : "webp";
      const path = `${websiteId}/${crypto.randomUUID()}.${extension}`;
      const { error } = await supabase.storage.from("website-assets").upload(path, file, {
        cacheControl: "31536000",
        contentType: file.type,
        upsert: false,
      });
      if (error) throw new Error(error.message);
      const { data } = supabase.storage.from("website-assets").getPublicUrl(path);
      const url = data.publicUrl;
      if (field === "logoUrl" || field === "heroImageUrl") {
        setContent((current) => ({ ...current, [field]: url }));
      } else if (field.startsWith("product:")) {
        const productId = field.slice("product:".length);
        setContent((current) => ({
          ...current,
          products: current.products.map((product) => product.id === productId ? { ...product, imageUrl: url } : product),
        }));
      }
      setMessage("Imagem carregada. A alteração será salva automaticamente.");
    } catch (error) {
      setMessage(error instanceof Error ? `Upload não concluído: ${error.message}` : "Não foi possível enviar a imagem.");
    } finally { setUploading(""); }
  }

  function update<K extends keyof WebsiteContent>(key: K, value: WebsiteContent[K]) {
    setContent((current) => ({ ...current, [key]: value }));
  }

  function updateSection(index: number, key: keyof WebsiteSection, value: string) {
    setContent((current) => ({
      ...current,
      sections: current.sections.map((section, i) => i === index ? { ...section, [key]: value } : section),
    }));
  }

  function moveSection(index: number, offset: -1 | 1) {
    setContent((current) => {
      const next = [...current.sections];
      const destination = index + offset;
      if (destination < 0 || destination >= next.length) return current;
      [next[index], next[destination]] = [next[destination], next[index]];
      return { ...current, sections: next };
    });
  }

  function addSection() {
    if (content.sections.length >= 10) { setMessage("O limite atual é de 10 seções por site."); return; }
    update("sections", [...content.sections, { heading: "Nova seção", body: "" }]);
  }

  function updateProduct(id: string, key: keyof WebsiteProduct, value: string) {
    setContent((current) => ({
      ...current,
      products: current.products.map((product) => product.id === id ? { ...product, [key]: value } : product),
    }));
  }

  function addProduct() {
    if (content.products.length >= 24) { setMessage("O limite atual é de 24 produtos por site."); return; }
    update("products", [...content.products, { id: crypto.randomUUID(), name: "", description: "", price: "", imageUrl: "" }]);
  }

  const previewWidth = previewDevice === "mobile" ? 390 : previewDevice === "tablet" ? 768 : "100%";
  const previewStyle: CSSProperties = {
    width: previewWidth,
    maxWidth: "100%",
    minHeight: previewDevice === "mobile" ? 680 : 520,
    margin: "0 auto",
    background: "#fffdf9",
    borderTop: `5px solid ${preview.accent}`,
    overflow: "hidden",
    fontFamily: preview.fontFamily === "sans" ? "Arial, sans-serif" : "Georgia, serif",
  };

  return <div className="editor-layout" style={{ display: "grid", gridTemplateColumns: "minmax(0, .95fr) minmax(0, 1.05fr)", gap: 16, alignItems: "start" }}>
    <section className="panel">
      <div className="panel-head">
        <div>
          <h2>Editar conteúdo</h2>
          <p>Textos, imagens, seções e produtos podem ser ajustados nesta tela.</p>
          <p style={{ color: "var(--muted)", marginTop: 4 }} aria-live="polite">
            {autoState === "saving" ? "Salvando alterações…" : autoState === "saved" ? "Todas as alterações foram salvas." : autoState === "error" ? "Falha no salvamento automático. Use Salvar alterações." : "Salvamento automático ativado."}
          </p>
        </div>
        <span className={`status ${status === "published" ? "good" : ""}`}>{status === "published" ? "Publicado" : "Rascunho"}</span>
      </div>

      <div className="field"><label>Nome do projeto</label><input value={name} maxLength={80} onChange={(e) => setName(e.target.value)} /></div>
      <div className="field"><label>Título principal</label><input value={content.title} maxLength={120} onChange={(e) => update("title", e.target.value)} /></div>
      <div className="field"><label>Descrição principal</label><textarea value={content.subtitle} maxLength={500} onChange={(e) => update("subtitle", e.target.value)} /></div>
      <div className="field"><label>Sobre o negócio</label><textarea value={content.about} maxLength={1600} onChange={(e) => update("about", e.target.value)} /></div>

      <div className="field"><label>Logotipo (JPG, PNG ou WebP · até 8 MB)</label><input type="file" accept="image/jpeg,image/png,image/webp" disabled={Boolean(uploading)} onChange={(e) => { const file = e.target.files?.[0]; if (file) void uploadImage(file, "logoUrl"); e.currentTarget.value = ""; }} /></div>
      {content.logoUrl && isSafeImageUrl(content.logoUrl) && <div style={{ display: "flex", alignItems: "center", gap: 12, margin: "0 0 14px" }}><img src={content.logoUrl} alt="Logotipo atual" style={{ width: 64, height: 64, objectFit: "contain", background: "#f3eee8", borderRadius: 8 }} /><button className="button secondary" type="button" onClick={() => update("logoUrl", "")}>Remover logotipo</button></div>}
      <div className="field"><label>Imagem de capa (JPG, PNG ou WebP · até 8 MB)</label><input type="file" accept="image/jpeg,image/png,image/webp" disabled={Boolean(uploading)} onChange={(e) => { const file = e.target.files?.[0]; if (file) void uploadImage(file, "heroImageUrl"); e.currentTarget.value = ""; }} /></div>
      {content.heroImageUrl && isSafeImageUrl(content.heroImageUrl) && <div style={{ marginBottom: 14 }}><img src={content.heroImageUrl} alt="Imagem de capa atual" style={{ width: "100%", maxHeight: 170, objectFit: "cover", borderRadius: 8 }} /><button className="button secondary" type="button" onClick={() => update("heroImageUrl", "")}>Remover imagem de capa</button></div>}

      <div className="field"><label>WhatsApp comercial</label><input value={content.contact} maxLength={32} onChange={(e) => update("contact", e.target.value)} /></div>
      <div className="field"><label>Telefone</label><input value={content.phone ?? ""} maxLength={32} onChange={(e) => update("phone", e.target.value)} /></div>
      <div className="field"><label>E-mail</label><input type="email" value={content.contactEmail ?? ""} maxLength={160} onChange={(e) => update("contactEmail", e.target.value)} /></div>
      <div className="field"><label>Endereço informado</label><input value={content.address ?? ""} maxLength={220} onChange={(e) => update("address", e.target.value)} /></div>
      <div className="form-grid">
        <div className="field"><label>Categoria do negócio</label><input value={content.business?.category ?? ""} maxLength={60} onChange={(e) => update("business", { ...content.business, category: e.target.value })} /></div>
        <div className="field"><label>Cidade</label><input value={content.business?.city ?? ""} maxLength={90} onChange={(e) => update("business", { ...content.business, city: e.target.value })} /></div>
      </div>
      <div className="field"><label>Direção visual</label><input value={content.visualStyle ?? ""} maxLength={80} onChange={(e) => update("visualStyle", e.target.value)} placeholder="Ex.: editorial e acolhedora" /></div>
      <div className="field"><label>Texto do botão principal</label><input value={content.buttonLabel ?? ""} maxLength={50} onChange={(e) => update("buttonLabel", e.target.value)} placeholder="Ex.: Fale conosco" /></div>
      <div className="field"><label>Link do botão (URL https:// ou mailto:)</label><input value={content.buttonUrl ?? ""} maxLength={500} onChange={(e) => update("buttonUrl", e.target.value)} /></div>
      <div className="field"><label>Rodapé</label><textarea value={content.footer ?? ""} maxLength={500} onChange={(e) => update("footer", e.target.value)} placeholder="Informações de encerramento fornecidas pelo negócio." /></div>
      <div className="form-grid">
        <div className="field"><label>Cor de destaque</label><input type="color" value={content.accent} onChange={(e) => update("accent", e.target.value)} style={{ height: 44, padding: 4 }} /></div>
        <div className="field"><label>Tipografia</label><select value={content.fontFamily ?? "serif"} onChange={(e) => update("fontFamily", e.target.value as "serif" | "sans")}><option value="serif">Serifada editorial</option><option value="sans">Sem serifa</option></select></div>
      </div>

      <div className="panel-head" style={{ marginTop: 28 }}><div><h2>Seções da página</h2><p>Adicione, remova e reorganize até 10 seções.</p></div><button className="button secondary" type="button" onClick={addSection}>Adicionar seção</button></div>
      {content.sections.map((section, index) => <article key={index} style={{ border: "1px solid var(--line)", borderRadius: 8, padding: 12, marginBottom: 10 }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 8 }}>
          <strong style={{ fontSize: 12 }}>Seção {index + 1}</strong>
          <div style={{ display: "flex", gap: 5 }}>
            <button type="button" className="button secondary" disabled={index === 0} onClick={() => moveSection(index, -1)} aria-label="Mover seção para cima">↑</button>
            <button type="button" className="button secondary" disabled={index === content.sections.length - 1} onClick={() => moveSection(index, 1)} aria-label="Mover seção para baixo">↓</button>
            <button type="button" className="button secondary" onClick={() => update("sections", content.sections.filter((_, i) => i !== index))}>Remover</button>
          </div>
        </div>
        <div className="field"><label>Título</label><input value={section.heading} maxLength={100} onChange={(e) => updateSection(index, "heading", e.target.value)} /></div>
        <div className="field"><label>Texto</label><textarea value={section.body} maxLength={1200} onChange={(e) => updateSection(index, "body", e.target.value)} /></div>
        <div className="field"><label>Imagem da seção (URL https://)</label><input value={section.imageUrl ?? ""} maxLength={2000} onChange={(e) => updateSection(index, "imageUrl", e.target.value)} /></div>
        <div className="field"><label>Texto do link (opcional)</label><input value={section.buttonLabel ?? ""} maxLength={50} onChange={(e) => updateSection(index, "buttonLabel", e.target.value)} /></div>
        <div className="field"><label>Destino do link (opcional)</label><input value={section.buttonUrl ?? ""} maxLength={500} onChange={(e) => updateSection(index, "buttonUrl", e.target.value)} /></div>
      </article>)}

      <div className="panel-head" style={{ marginTop: 28 }}><div><h2>Produtos e serviços</h2><p>Preencha somente dados comerciais confirmados.</p></div><button className="button secondary" type="button" onClick={addProduct}>Adicionar item</button></div>
      {content.products.map((product, index) => <article key={product.id} style={{ border: "1px solid var(--line)", borderRadius: 8, padding: 12, marginBottom: 10 }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 8 }}><strong style={{ fontSize: 12 }}>Item {index + 1}</strong><button className="button secondary" type="button" onClick={() => update("products", content.products.filter((item) => item.id !== product.id))}>Remover</button></div>
        <div className="field"><label>Nome</label><input value={product.name} maxLength={100} onChange={(e) => updateProduct(product.id, "name", e.target.value)} /></div>
        <div className="field"><label>Descrição</label><textarea value={product.description} maxLength={700} onChange={(e) => updateProduct(product.id, "description", e.target.value)} /></div>
        <div className="field"><label>Preço informado</label><input value={product.price} maxLength={60} onChange={(e) => updateProduct(product.id, "price", e.target.value)} placeholder="Deixe em branco se não informado" /></div>
        <div className="field"><label>Imagem do item (até 8 MB)</label><input type="file" accept="image/jpeg,image/png,image/webp" disabled={Boolean(uploading)} onChange={(e) => { const file = e.target.files?.[0]; if (file) void uploadImage(file, `product:${product.id}`); e.currentTarget.value = ""; }} /></div>
        {product.imageUrl && isSafeImageUrl(product.imageUrl) && <img src={product.imageUrl} alt={product.name || "Imagem do item"} style={{ width: 92, height: 72, objectFit: "cover", borderRadius: 6 }} />}
      </article>)}

      {message && <div className={message.includes("não") || message.includes("Falha") || message.includes("Erro") ? "form-error" : "form-success"} role="status">{message}</div>}
      {uploading && <p style={{ color: "var(--muted)", fontSize: 11 }}>Enviando imagem…</p>}
      <div style={{ display: "flex", gap: 9, flexWrap: "wrap", marginTop: 14 }}>
        <button className="button" disabled={busy || Boolean(uploading)} onClick={() => void save()}>{busy ? "Salvando…" : "Salvar alterações"}</button>
        <button className="button secondary" disabled={busy || Boolean(uploading)} onClick={() => void publish()}>{status === "published" ? "Atualizar publicação" : "Publicar site"}</button>
        {status === "published" && <button className="button secondary" disabled={busy} onClick={() => void unpublish()}>Despublicar</button>}
        <button className="button secondary" disabled={busy} onClick={() => void loadHistory()}>Histórico</button>
      </div>
      {publishedUrl && <p style={{ fontSize: 11, color: "var(--muted)" }}>Endereço atual: <a className="text-link" href={publishedUrl} target="_blank" rel="noreferrer">{publishedUrl}</a></p>}
      {historyOpen && <section style={{ borderTop: "1px solid var(--line)", marginTop: 18, paddingTop: 14 }}>
        <h3 style={{ font: "400 20px Georgia,serif" }}>Versões anteriores</h3>
        {!history.length ? <p style={{ color: "var(--muted)", fontSize: 12 }}>Nenhuma versão anterior registrada ainda.</p> : history.map((revision) => <div key={revision.id} className="site-row"><div><strong>{revision.name}</strong><small>{new Date(revision.created_at).toLocaleString("pt-BR", { timeZone: "America/Sao_Paulo" })}</small></div><button className="button secondary" disabled={busy} onClick={() => void restoreRevision(revision.id)}>Restaurar</button></div>)}
      </section>}
    </section>

    <section className="panel" style={{ position: "sticky", top: 16 }}>
      <div className="panel-head"><div><h2>Pré-visualização</h2><p>Prévia responsiva do conteúdo atual.</p></div></div>
      <div style={{ display: "flex", gap: 6, justifyContent: "center", marginBottom: 14 }}>
        {(["mobile", "tablet", "desktop"] as const).map((device) => <button key={device} className={`button ${previewDevice === device ? "" : "secondary"}`} style={{ minHeight: 34, padding: "0 10px" }} onClick={() => setPreviewDevice(device)}>{device === "mobile" ? "Celular" : device === "tablet" ? "Tablet" : "Computador"}</button>)}
      </div>
      <div style={{ overflowX: "auto", padding: 8, background: "#eee8df", borderRadius: 10 }}>
        <div style={previewStyle}>
          <header style={{ padding: 18, display: "flex", alignItems: "center", gap: 12, justifyContent: "space-between" }}>
            {preview.logoUrl && isSafeImageUrl(preview.logoUrl) ? <img src={preview.logoUrl} alt="Logotipo" style={{ width: 48, height: 48, objectFit: "contain" }} /> : null}
            <strong style={{ font: "16px Arial,sans-serif" }}>{name || "Seu negócio"}</strong>
          </header>
          {preview.heroImageUrl && isSafeImageUrl(preview.heroImageUrl) && <img src={preview.heroImageUrl} alt="" style={{ display: "block", width: "100%", maxHeight: 250, objectFit: "cover" }} />}
          <div style={{ textAlign: "center", padding: "clamp(24px,5vw,54px) 22px" }}>
            <div style={{ color: preview.accent, font: "700 10px Arial,sans-serif", letterSpacing: ".12em", textTransform: "uppercase" }}>{name || "Seu negócio"}</div>
            <h2 style={{ font: "400 clamp(28px,5vw,46px)/1.12 Georgia,serif", margin: "18px auto", maxWidth: 560 }}>{preview.title || "Seu título principal"}</h2>
            <p style={{ color: "#77726b", font: "13px/1.8 Arial,sans-serif", maxWidth: 550, margin: "0 auto" }}>{preview.subtitle || "A descrição informada será exibida aqui."}</p>
            {(preview.buttonLabel || preview.contact) && <span style={{ display: "inline-block", marginTop: 22, background: preview.accent, color: "white", padding: "11px 17px", borderRadius: 5, font: "12px Arial,sans-serif" }}>{preview.buttonLabel || "Entrar em contato"}</span>}
          </div>
          {preview.about && <section style={{ padding: "26px 22px", borderTop: "1px solid #e5ded4" }}><h3 style={{ font: "400 25px Georgia,serif" }}>Sobre</h3><p style={{ color: "#77726b", font: "13px/1.8 Arial,sans-serif" }}>{preview.about}</p></section>}
          {preview.sections.map((section, index) => <section key={index} style={{ padding: "22px", borderTop: "1px solid #e5ded4" }}><h3 style={{ font: "400 22px Georgia,serif" }}>{section.heading}</h3><p style={{ color: "#77726b", font: "13px/1.8 Arial,sans-serif" }}>{section.body}</p>{section.imageUrl && isSafeImageUrl(section.imageUrl) && <img src={section.imageUrl} alt="" style={{ width: "100%", maxHeight: 180, objectFit: "cover" }} />}</section>)}
          {preview.products.length > 0 && <section style={{ padding: 22, borderTop: "1px solid #e5ded4" }}><h3 style={{ font: "400 23px Georgia,serif" }}>Produtos e serviços</h3><div style={{ display: "grid", gridTemplateColumns: previewDevice === "mobile" ? "1fr" : "repeat(2,minmax(0,1fr))", gap: 12 }}>{preview.products.filter((product) => product.name || product.description).map((product) => <article key={product.id} style={{ border: "1px solid #e5ded4", padding: 10 }}>{product.imageUrl && isSafeImageUrl(product.imageUrl) && <img src={product.imageUrl} alt="" style={{ width: "100%", height: 100, objectFit: "cover" }} />}<strong>{product.name}</strong><p style={{ font: "12px/1.6 Arial,sans-serif", color: "#77726b" }}>{product.description}</p>{product.price && <b>{product.price}</b>}</article>)}</div></section>}
          <footer style={{ padding: 22, textAlign: "center", color: "#77726b", borderTop: "1px solid #e5ded4", font: "11px/1.6 Arial,sans-serif" }}>{preview.footer || "Rodapé do negócio"}<br />{preview.phone || ""} {preview.contactEmail || ""} {preview.address || ""}</footer>
        </div>
      </div>
    </section>
    <style jsx>{`@media (max-width: 900px) { .editor-layout { grid-template-columns: 1fr !important; } }`}</style>
  </div>;
}
