import Link from "next/link";
import { brand } from "@/lib/brand";

export function Brand({ light = false }: { light?: boolean }) {
  return <Link href="/" className="brand" style={light ? { color: "#f4eee7" } : undefined}>
    <span className="brand-mark">s</span><span>{brand.name.toLowerCase()}</span>
  </Link>;
}
