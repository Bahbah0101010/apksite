import Link from "next/link";
import { PLANS, formatBRL } from "@/lib/plans";

export function PricingCards() {
  return <div className="pricing-grid">
    {Object.values(PLANS).map((plan) => <article className={`price-card ${plan.code === "professional" ? "featured" : ""}`} key={plan.code}>
      <div className="price-top"><span className="price-name">{plan.name}</span>{plan.code === "professional" && <span className="price-kicker">Mais escolhido</span>}</div>
      <div className="price-value">{plan.priceCents === 0 ? "Grátis" : formatBRL(plan.priceCents)}</div>
      <div className="price-period">{plan.billing}</div>
      <p className="price-summary">{plan.summary}</p>
      <ul className="price-list">{plan.features.map((feature) => <li key={feature}>{feature}</li>)}</ul>
      <Link className={`button ${plan.code === "professional" ? "" : "secondary"}`} href="/signup">Começar com {plan.name}</Link>
    </article>)}
  </div>;
}
