"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { LayoutDashboard, Globe2, Plus, CreditCard, Settings, Shield, LogOut } from "lucide-react";
import { createSupabaseBrowserClient } from "@/lib/supabase/browser";
import { Brand } from "@/components/brand";

const links = [
  { href: "/app", label: "Visão geral", icon: LayoutDashboard },
  { href: "/app/sites", label: "Meus sites", icon: Globe2 },
  { href: "/app/sites/new", label: "Criar site", icon: Plus },
  { href: "/app/assinatura", label: "Plano e pagamentos", icon: CreditCard },
  { href: "/app/configuracoes", label: "Configurações", icon: Settings },
];

export function AppSidebar({ email, admin }: { email: string; admin: boolean }) {
  const pathname = usePathname();
  const router = useRouter();
  async function signOut() {
    const supabase = createSupabaseBrowserClient();
    await supabase.auth.signOut();
    router.replace("/login"); router.refresh();
  }
  return <aside className="sidebar">
    <div className="sidebar-brand"><Brand light /></div>
    <div className="sidebar-label">Workspace</div>
    <nav className="sidebar-nav">
      {links.map(({ href, label, icon: Icon }) => <Link key={href} href={href} className={pathname === href || (href !== "/app" && pathname.startsWith(`${href}/`)) ? "active" : ""}><Icon size={15} strokeWidth={1.7} />{label}</Link>)}
      {admin && <><div className="sidebar-label">Administração</div><Link href="/admin" className={pathname.startsWith("/admin") ? "active" : ""}><Shield size={15} strokeWidth={1.7} />Painel administrativo</Link></>}
    </nav>
    <div className="sidebar-bottom"><div style={{ marginBottom: 10, overflowWrap: "anywhere" }}>{email}</div><button onClick={signOut} style={{ display: "flex", gap: 8, alignItems: "center", border: 0, padding: 0, color: "#d8cfc6", background: "transparent", fontSize: 11 }}><LogOut size={13} /> Sair da conta</button></div>
  </aside>;
}
