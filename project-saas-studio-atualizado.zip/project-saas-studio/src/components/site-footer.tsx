import { Brand } from "@/components/brand";

export function SiteFooter() {
  return <footer className="footer"><div className="container footer-inner">
    <Brand light /><small>© {new Date().getFullYear()} Studio. Feito para negócios que querem crescer.</small>
  </div></footer>;
}
