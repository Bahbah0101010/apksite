import type { Metadata } from "next";
import Link from "next/link";
import { AuthForm } from "@/components/auth-form";
import { Brand } from "@/components/brand";

export const metadata: Metadata = { title: "Redefinir senha" };

export default function ResetPasswordPage() {
  return <main className="auth-wrap">
    <aside className="auth-aside"><div><Brand /><h1>Um novo acesso, com segurança.</h1><p>Escolha uma nova senha para continuar no seu espaço de criação.</p></div><div className="auth-aside-foot">Use uma senha exclusiva para sua conta.</div></aside>
    <section className="auth-main"><div className="auth-card"><h2>Redefinir senha.</h2><p>Defina uma senha com pelo menos oito caracteres.</p><AuthForm mode="reset" /><div className="auth-footnote"><Link href="/login" className="text-link">Voltar ao login</Link></div></div></section>
  </main>;
}
