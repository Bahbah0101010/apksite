import { redirect } from "next/navigation";
import { createSupabaseServerClient } from "@/lib/supabase/server";
import { isAllowedAdmin } from "@/lib/auth";
import { AdminDashboard } from "@/components/admin-dashboard";
import { AppSidebar } from "@/components/app-sidebar";
import { Heartbeat } from "@/components/heartbeat";

export default async function AdminPage() {
  const supabase = await createSupabaseServerClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login");
  if (!isAllowedAdmin(user.email)) redirect("/app");
  return <div className="app-layout"><AppSidebar email={user.email ?? "Administrador"} admin /><main className="app-main"><AdminDashboard /></main><Heartbeat /></div>;
}
