import type { MetadataRoute } from "next";

export default function robots(): MetadataRoute.Robots {
  const base = process.env.NEXT_PUBLIC_APP_URL ?? "https://example.invalid";
  return { rules: { userAgent: "*", allow: "/", disallow: ["/app", "/admin", "/api"] }, sitemap: `${base.replace(/\/$/, "")}/sitemap.xml` };
}
