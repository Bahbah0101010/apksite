import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import "./globals.css";
import { brand } from "@/lib/brand";
import { CookieConsent } from "@/components/cookie-consent";
import { AnalyticsTracker } from "@/components/heartbeat";

export const metadata: Metadata = {
  title: { default: `${brand.name} — sites para negócios reais`, template: `%s | ${brand.name}` },
  description: "Crie, personalize e publique sites profissionais para seu negócio.",
  applicationName: brand.name,
  manifest: "/site.webmanifest",
  icons: {
    icon: [
      { url: "/favicon.ico", sizes: "any" },
      { url: "/icons/icon-192.png", sizes: "192x192", type: "image/png" },
      { url: "/icons/icon-512.png", sizes: "512x512", type: "image/png" },
    ],
    apple: [{ url: "/icons/apple-touch-icon.png", sizes: "180x180", type: "image/png" }],
  },
  appleWebApp: { capable: true, statusBarStyle: "default", title: brand.name },
};

export const viewport: Viewport = {
  themeColor: "#F5F1EB",
  width: "device-width",
  initialScale: 1,
  viewportFit: "cover",
};

export default function RootLayout({ children }: Readonly<{ children: ReactNode }>) {
  return <html lang="pt-BR"><body>{children}<AnalyticsTracker /><CookieConsent /></body></html>;
}
