import type { Metadata } from "next";
import Link from "next/link";
import { AuthForm } from "@/components/auth-form";
import { Brand } from "@/components/brand";

export const metadata: Metadata = { title: "Criar conta" };

export default function SignupPage() {
  return <main className="auth-wrap">
    <aside className="auth-aside"><div><Brand /><h1>Uma boa presença digital começa com clareza.</h1><p>Crie sua conta, organize as informações do seu negócio e monte seu primeiro projeto.</p></div><div className="auth-aside-foot">Sem números de demonstração. Seus dados, seus projetos.</div></aside>
    <section className="auth-main"><div className="auth-card"><h2>Comece por aqui.</h2><p>Preencha os dados para criar seu acesso.</p><AuthForm mode="signup" /><div className="auth-footnote"><Link href="/" className="text-link">Voltar ao início</Link></div></div></section>
  </main>;
}
