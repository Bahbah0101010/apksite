import type { Metadata } from "next";
import Link from "next/link";
import { AuthForm } from "@/components/auth-form";
import { Brand } from "@/components/brand";

export const metadata: Metadata = { title: "Entrar" };

export default function LoginPage() {
  return <main className="auth-wrap">
    <aside className="auth-aside"><div><Brand /><h1>Seu espaço de criação começa por aqui.</h1><p>Entre para acessar seus projetos, acompanhar publicações e continuar de onde parou.</p></div><div className="auth-aside-foot">Um ambiente organizado para suas ideias.</div></aside>
    <section className="auth-main"><div className="auth-card"><h2>Boas-vindas.</h2><p>Entre com os dados da sua conta.</p><AuthForm mode="login" /><div className="auth-footnote"><Link href="/" className="text-link">Voltar ao início</Link></div></div></section>
  </main>;
}
