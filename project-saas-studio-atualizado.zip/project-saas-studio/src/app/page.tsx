/* eslint-disable @next/next/no-img-element */
import Link from "next/link";
import { SiteHeader } from "@/components/site-header";
import { SiteFooter } from "@/components/site-footer";
import { PricingCards } from "@/components/pricing-cards";

export default function HomePage() {
  return <>
    <SiteHeader />
    <main>
      <section className="container hero">
        <div>
          <span className="eyebrow">Presença digital com intenção</span>
          <h1>Seu próximo site começa com <em>uma ideia.</em></h1>
          <p className="hero-copy">Crie sites profissionais para o seu negócio, ajuste cada detalhe e publique sem precisar começar do zero ou aprender programação.</p>
          <div className="hero-buttons"><Link className="button" href="/signup">Criar meu site</Link><Link className="button secondary" href="#planos">Conhecer os planos</Link></div>
          <div className="hero-note">Editor visual · Projetos organizados · Publicação em um só lugar</div>
        </div>
        <div className="hero-visual" aria-label="Área reservada para a imagem principal da marca">
          <div className="preview-frame"><div className="preview-photo">
            <img src="/brand/cover.jpg" alt="Fotografia de referência da identidade visual do Studio" />
          </div></div>
          <div className="preview-tag"><strong>Uma presença mais clara.</strong><small>Seu negócio, apresentado do seu jeito.</small></div>
        </div>
      </section>

      <section className="section section-white" id="recursos"><div className="container">
        <div className="section-heading"><div><span className="eyebrow">Uma ferramenta, várias possibilidades</span><h2>Seu trabalho merece<br />uma boa apresentação.</h2></div><p>Organize as informações do negócio, monte páginas com consistência visual e mantenha tudo atualizado no mesmo espaço.</p></div>
        <div className="feature-grid">
          <article className="feature-card"><span className="feature-index">01</span><h3>Criação orientada</h3><p>Conte sobre o negócio e receba uma estrutura inicial que pode ser ajustada antes de publicar.</p></article>
          <article className="feature-card"><span className="feature-index">02</span><h3>Edição sem atrito</h3><p>Altere textos, cores, imagens e seções em um editor visual com prévia para diferentes telas.</p></article>
          <article className="feature-card"><span className="feature-index">03</span><h3>Projetos em ordem</h3><p>Acompanhe rascunhos, publicações, plano atual e atividade da conta em um só painel.</p></article>
        </div>
      </div></section>

      <section className="section" id="como-funciona"><div className="container">
        <div className="section-heading"><div><span className="eyebrow">Do primeiro passo à publicação</span><h2>Simples de começar.<br />Fácil de continuar.</h2></div></div>
        <div className="steps">
          <article className="step"><span>01 / Conte</span><h3>Apresente seu negócio</h3><p>Informe o que você oferece, os contatos e o estilo que representa sua marca.</p></article>
          <article className="step"><span>02 / Ajuste</span><h3>Refine cada seção</h3><p>Revise o conteúdo e personalize a apresentação com o editor e a pré-visualização.</p></article>
          <article className="step"><span>03 / Publique</span><h3>Coloque no ar</h3><p>Publique o projeto e acompanhe o status diretamente no seu painel.</p></article>
        </div>
      </div></section>

      <section className="section section-white" id="planos"><div className="container">
        <div className="section-heading"><div><span className="eyebrow">Planos transparentes</span><h2>Comece no seu ritmo.</h2></div><p>Os limites de geração são aplicados no servidor e exibidos na sua conta. O plano Free tem duração de 30 dias.</p></div>
        <PricingCards />
      </div></section>

      <section className="section"><div className="container" style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: 24, flexWrap: "wrap" }}>
        <div><span className="eyebrow">Comece com o essencial</span><h2 style={{ font: "400 clamp(32px, 4vw, 48px) Georgia, serif", letterSpacing: "-.045em", margin: "14px 0 8px" }}>Uma página bem feita<br />abre boas conversas.</h2><p style={{ color: "var(--muted)", fontSize: 12 }}>Crie sua conta e organize o próximo passo da sua presença digital.</p></div>
        <Link className="button dark" href="/signup">Começar agora</Link>
      </div></section>
    </main>
    <SiteFooter />
  </>;
}
