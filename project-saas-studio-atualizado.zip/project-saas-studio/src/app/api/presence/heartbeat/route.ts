import { NextResponse } from "next/server";
import { z } from "zod";
import { createSupabaseServerClient } from "@/lib/supabase/server";
import { createSupabaseAdminClient } from "@/lib/supabase/admin";

const bodySchema = z.object({ sessionId: z.string().uuid(), page: z.string().max(250).optional() });

export async function POST(request: Request) {
  const parsed = bodySchema.safeParse(await request.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ error: "Sessão inválida." }, { status: 400 });
  const supabase = await createSupabaseServerClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "Não autenticado." }, { status: 401 });

  const admin = createSupabaseAdminClient();
  const { data: existing, error: lookupError } = await admin
    .from("user_sessions")
    .select("user_id")
    .eq("session_id", parsed.data.sessionId)
    .maybeSingle();
  if (lookupError) return NextResponse.json({ error: "Não foi possível validar a sessão." }, { status: 503 });
  if (existing && existing.user_id !== user.id) return NextResponse.json({ error: "Esta sessão pertence a outra conta." }, { status: 409 });

  const now = new Date().toISOString();
  const { error } = await admin.from("user_sessions").upsert({
    session_id: parsed.data.sessionId,
    user_id: user.id,
    current_path: parsed.data.page ?? "/app",
    last_seen: now,
    user_agent: request.headers.get("user-agent")?.slice(0, 240) ?? null,
  }, { onConflict: "session_id" });
  if (error) return NextResponse.json({ error: "Não foi possível atualizar a presença." }, { status: 503 });
  return NextResponse.json({ ok: true, lastSeen: now });
}
