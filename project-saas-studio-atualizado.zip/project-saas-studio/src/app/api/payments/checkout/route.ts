import { randomUUID } from "node:crypto";
import { NextResponse } from "next/server";
import { z } from "zod";
import { PLANS } from "@/lib/plans";
import { createSupabaseServerClient } from "@/lib/supabase/server";
import { createSupabaseAdminClient } from "@/lib/supabase/admin";
import { createCheckoutPreference } from "@/lib/mercadopago";
import { getRequestOrigin } from "@/lib/http";
import { checkUserRateLimit } from "@/lib/rate-limit";

const bodySchema = z.object({ planCode: z.enum(["professional", "business"]) });

export async function POST(request: Request) {
  const parsed = bodySchema.safeParse(await request.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ error: "Plano inválido." }, { status: 400 });
  const auth = await createSupabaseServerClient();
  const { data: { user } } = await auth.auth.getUser();
  if (!user?.email) return NextResponse.json({ error: "Entre na sua conta para contratar um plano." }, { status: 401 });
  const rate = await checkUserRateLimit(user.id, "payment.checkout", 3, 60);
  if (!rate.available) return NextResponse.json({ error: "O controle de segurança está indisponível. Tente novamente." }, { status: 503 });
  if (!rate.allowed) return NextResponse.json(
    { error: "Muitas tentativas de checkout em sequência. Aguarde e tente novamente." },
    { status: 429, headers: { "Retry-After": String(rate.retryAfterSeconds) } },
  );
  const plan = PLANS[parsed.data.planCode];
  const admin = createSupabaseAdminClient();
  const externalReference = randomUUID();
  const amount = plan.priceCents / 100;
  const mode = process.env.MERCADOPAGO_ENV === "production" ? "live" : "test";

  const { error: insertError } = await admin.from("payments").insert({
    user_id: user.id,
    plan_code: plan.code,
    provider: "mercadopago",
    external_reference: externalReference,
    status: "pending",
    amount_cents: plan.priceCents,
    currency: "BRL",
    mode,
  });
  if (insertError) return NextResponse.json({ error: "Não foi possível registrar a tentativa de pagamento." }, { status: 503 });

  try {
    const origin = getRequestOrigin(request);
    const preference = await createCheckoutPreference({
      externalReference,
      title: `Studio — plano ${plan.name}`,
      amount,
      payerEmail: user.email,
      backUrl: origin,
      notificationUrl: `${origin}/api/webhooks/mercadopago`,
    });
    const { error: updateError } = await admin.from("payments").update({
      provider_preference_id: preference.preferenceId,
      checkout_url: preference.checkoutUrl,
    }).eq("external_reference", externalReference);
    if (updateError) throw new Error("O checkout foi criado, mas não foi possível salvar o endereço de pagamento.");
    await admin.from("platform_events").insert({ user_id: user.id, event_type: "payment.checkout_created", payload: { external_reference: externalReference, plan_code: plan.code, mode } });
    return NextResponse.json({ checkoutUrl: preference.checkoutUrl });
  } catch (error) {
    await admin.from("payments").update({ status: "cancelled", failure_reason: error instanceof Error ? error.message : "checkout_error" }).eq("external_reference", externalReference);
    return NextResponse.json({ error: error instanceof Error ? error.message : "Não foi possível iniciar o checkout." }, { status: 502 });
  }
}
