import { createHash, randomUUID } from "node:crypto";
import { NextResponse } from "next/server";
import { cookies } from "next/headers";
import { z } from "zod";
import { createSupabaseServerClient } from "@/lib/supabase/server";
import { createSupabaseAdminClient } from "@/lib/supabase/admin";

const bodySchema = z.object({ path: z.string().trim().min(1).max(250), referrer: z.string().max(500).nullable().optional(), sessionId: z.string().uuid() });

export async function POST(request: Request) {
  const cookieStore = await cookies();
  if (cookieStore.get("studio_analytics_consent")?.value !== "yes") return NextResponse.json({ accepted: false }, { status: 202 });
  const parsed = bodySchema.safeParse(await request.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ error: "Evento inválido." }, { status: 400 });
  const secret = process.env.ANALYTICS_HASH_SECRET;
  if (!secret || secret.length < 32) return NextResponse.json({ error: "Analytics não configurado." }, { status: 503 });

  let visitorId = cookieStore.get("studio_visitor_id")?.value;
  if (!visitorId) {
    visitorId = randomUUID();
    cookieStore.set("studio_visitor_id", visitorId, { httpOnly: true, secure: process.env.NODE_ENV === "production", sameSite: "lax", path: "/", maxAge: 60 * 60 * 24 * 180 });
  }
  const visitorKey = createHash("sha256").update(`${secret}:${visitorId}`).digest("hex");
  const auth = await createSupabaseServerClient();
  const { data: { user } } = await auth.auth.getUser();
  const admin = createSupabaseAdminClient();
  const now = new Date().toISOString();
  const userAgent = request.headers.get("user-agent")?.slice(0, 240) ?? null;
  const path = parsed.data.path.startsWith("/") ? parsed.data.path : "/";
  const referrer = parsed.data.referrer?.startsWith("http") ? parsed.data.referrer.slice(0, 500) : null;

  const { error: sessionError } = await admin.from("visitor_sessions").upsert({
    visitor_key: visitorKey,
    last_seen: now,
    referrer,
    user_agent: userAgent,
    consented: true,
  }, { onConflict: "visitor_key" });
  if (sessionError) return NextResponse.json({ error: "Não foi possível registrar a sessão." }, { status: 503 });
  const { error } = await admin.from("analytics_events").insert({
    event_type: "page_view",
    visitor_key: visitorKey,
    session_id: parsed.data.sessionId,
    user_id: user?.id ?? null,
    page_path: path,
    referrer,
    user_agent: userAgent,
    is_bot: /bot|crawler|spider|headless/i.test(userAgent ?? ""),
  });
  if (error) return NextResponse.json({ error: "Não foi possível registrar a visualização." }, { status: 503 });
  return NextResponse.json({ accepted: true });
}
