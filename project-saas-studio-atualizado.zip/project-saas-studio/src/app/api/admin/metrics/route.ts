import { NextResponse } from "next/server";
import { createSupabaseServerClient } from "@/lib/supabase/server";
import { createSupabaseAdminClient } from "@/lib/supabase/admin";
import { isAllowedAdmin } from "@/lib/auth";
import { checkUserRateLimit } from "@/lib/rate-limit";

export async function GET() {
  const auth = await createSupabaseServerClient();
  const { data: { user } } = await auth.auth.getUser();
  if (!user || !isAllowedAdmin(user.email)) return NextResponse.json({ error: "Acesso administrativo não autorizado." }, { status: 403 });
  const rate = await checkUserRateLimit(user.id, "admin.metrics", 30, 60);
  if (!rate.available) return NextResponse.json({ error: "O controle de segurança está indisponível. Tente novamente." }, { status: 503 });
  if (!rate.allowed) return NextResponse.json(
    { error: "Consultas administrativas muito frequentes. Aguarde e tente novamente." },
    { status: 429, headers: { "Retry-After": String(rate.retryAfterSeconds) } },
  );
  const admin = createSupabaseAdminClient();
  const [{ data, error }, { data: generationUsage, error: usageError }] = await Promise.all([
    admin.rpc("admin_dashboard_metrics"),
    admin.rpc("admin_generation_metrics"),
  ]);
  if (error || usageError || !data || !generationUsage) {
    return NextResponse.json({ error: "Não foi possível consultar todos os indicadores reais. Verifique se as migrations estão aplicadas." }, { status: 503 });
  }
  return NextResponse.json({
    data: { ...data, generation_usage: generationUsage },
    updatedAt: new Date().toISOString(),
  });
}
