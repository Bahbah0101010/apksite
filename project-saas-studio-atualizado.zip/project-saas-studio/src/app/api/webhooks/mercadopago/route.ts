import { NextResponse } from "next/server";
import { createSupabaseAdminClient } from "@/lib/supabase/admin";
import { validateMercadoPagoSignature } from "@/lib/mercadopago";

export const runtime = "nodejs";

function statusFromProvider(value: string) {
  if (value === "approved") return "approved";
  if (value === "rejected") return "rejected";
  if (value === "cancelled") return "cancelled";
  if (value === "refunded") return "refunded";
  if (value === "charged_back") return "chargeback";
  return "pending";
}

export async function POST(request: Request) {
  const token = process.env.MERCADOPAGO_ACCESS_TOKEN;
  const secret = process.env.MERCADOPAGO_WEBHOOK_SECRET;
  if (!token || !secret) return NextResponse.json({ error: "Webhook não configurado." }, { status: 503 });
  const url = new URL(request.url);
  const body = await request.json().catch(() => ({}));
  const dataId = String(url.searchParams.get("data.id") ?? body?.data?.id ?? "");
  const requestId = request.headers.get("x-request-id");
  const valid = validateMercadoPagoSignature({
    signature: request.headers.get("x-signature"),
    requestId,
    dataId,
    secret,
  });
  if (!valid) return NextResponse.json({ error: "Assinatura do webhook inválida." }, { status: 401 });
  if (!/^\d+$/.test(dataId)) return NextResponse.json({ received: true, ignored: true });

  const providerResponse = await fetch(`https://api.mercadopago.com/v1/payments/${encodeURIComponent(dataId)}`, {
    headers: { Authorization: `Bearer ${token}` }, cache: "no-store",
  });
  const payment = await providerResponse.json().catch(() => ({}));
  if (!providerResponse.ok) return NextResponse.json({ error: "Não foi possível consultar o pagamento no Mercado Pago." }, { status: 502 });

  const externalReference = String(payment.external_reference ?? "");
  const status = statusFromProvider(String(payment.status ?? "pending"));
  const amountCents = Math.round(Number(payment.transaction_amount) * 100);
  if (!externalReference || !Number.isFinite(amountCents) || payment.currency_id !== "BRL") {
    return NextResponse.json({ error: "Dados do pagamento não conferem." }, { status: 422 });
  }

  const admin = createSupabaseAdminClient();
  const { data: localPayment, error: localError } = await admin.from("payments").select("amount_cents,mode").eq("external_reference", externalReference).eq("provider", "mercadopago").single();
  if (localError || !localPayment) return NextResponse.json({ error: "Referência de pagamento não encontrada." }, { status: 404 });
  if (localPayment.amount_cents !== amountCents) return NextResponse.json({ error: "O valor informado pelo provedor não corresponde ao pedido." }, { status: 422 });
  if (localPayment.mode === "live" && payment.live_mode !== true) return NextResponse.json({ error: "Pagamento de teste não pode confirmar um pedido de produção." }, { status: 422 });
  if (localPayment.mode === "test" && payment.live_mode === true) return NextResponse.json({ error: "Pagamento real recebido em ambiente de teste." }, { status: 422 });

  const providerEventId = `${dataId}:${status}:${String(payment.date_last_updated ?? payment.date_approved ?? "")}`;
  const feeCents = Array.isArray(payment.fee_details)
    ? Math.round(payment.fee_details.reduce((sum: number, item: { amount?: number }) => sum + Number(item.amount ?? 0), 0) * 100)
    : null;
  const refundedCents = Math.round(Number(payment.transaction_amount_refunded ?? 0) * 100);
  const mode = payment.live_mode === true ? "live" : "test";
  const { data: processed, error: processError } = await admin.rpc("process_mercadopago_payment", {
    p_external_reference: externalReference,
    p_provider_payment_id: String(payment.id),
    p_status: status,
    p_amount_cents: amountCents,
    p_fee_cents: feeCents,
    p_refunded_cents: refundedCents,
    p_currency: String(payment.currency_id),
    p_mode: mode,
    p_approved_at: payment.date_approved ?? null,
    p_status_detail: payment.status_detail ?? null,
    p_event_id: providerEventId,
    p_payload: payment,
  });
  if (processError) return NextResponse.json({ error: "Não foi possível processar o evento financeiro." }, { status: 503 });
  if (!processed?.ok) return NextResponse.json({ error: processed?.reason ?? "Pagamento não validado." }, { status: 422 });

  return NextResponse.json({ received: true });
}
