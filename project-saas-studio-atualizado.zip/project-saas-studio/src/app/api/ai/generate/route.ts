import { NextResponse } from "next/server";
import { z } from "zod";
import { createSupabaseServerClient } from "@/lib/supabase/server";
import { createSupabaseAdminClient } from "@/lib/supabase/admin";
import { jsonError } from "@/lib/http";
import { checkUserRateLimit } from "@/lib/rate-limit";

export const runtime = "nodejs";

const requestSchema = z.object({
  name: z.string().trim().min(2).max(80),
  category: z.string().trim().min(2).max(60),
  description: z.string().trim().min(15).max(1600),
  city: z.string().trim().max(90).nullable().optional(),
  address: z.string().trim().max(220).nullable().optional(),
  phone: z.string().trim().max(32).nullable().optional(),
  whatsapp: z.string().trim().max(32).nullable().optional(),
  email: z.string().trim().email().max(160).nullable().optional(),
  products: z.string().trim().max(3000).nullable().optional(),
  services: z.string().trim().max(3000).nullable().optional(),
  style: z.string().trim().max(80).optional(),
});

function parseModelJson(value: string) {
  const cleaned = value.trim().replace(/^```(?:json)?\s*/i, "").replace(/\s*```$/, "");
  return JSON.parse(cleaned) as Record<string, unknown>;
}

export async function POST(request: Request) {
  const parsed = requestSchema.safeParse(await request.json().catch(() => null));
  if (!parsed.success) return jsonError("Confira os campos do negócio e tente novamente.");
  if (!process.env.AI_API_KEY || !process.env.AI_MODEL) return jsonError("O provedor de IA ainda não foi configurado no servidor.", 503);

  const auth = await createSupabaseServerClient();
  const { data: { user }, error: authError } = await auth.auth.getUser();
  if (authError || !user) return jsonError("Entre na sua conta para gerar um site.", 401);

  const rate = await checkUserRateLimit(user.id, "ai.generate", 5, 60);
  if (!rate.available) return jsonError("O controle de segurança está indisponível. Tente novamente.", 503);
  if (!rate.allowed) return NextResponse.json(
    { error: "Muitas solicitações de geração em sequência. Aguarde e tente novamente." },
    { status: 429, headers: { "Retry-After": String(rate.retryAfterSeconds) } },
  );

  const admin = createSupabaseAdminClient();
  const { data: reservation, error: reserveError } = await admin.rpc("reserve_generation", { p_user_id: user.id });
  if (reserveError) return jsonError("Não foi possível validar seu limite diário. Tente novamente.", 503);
  if (!reservation?.ok) return jsonError(reservation?.reason ?? "Seu limite diário foi atingido.", 429);

  const reservationDay = String(reservation.usage_day ?? "");
  if (!reservationDay) {
    const fallbackDay = new Intl.DateTimeFormat("en-CA", {
      timeZone: "America/Sao_Paulo", year: "numeric", month: "2-digit", day: "2-digit",
    }).format(new Date());
    await admin.rpc("complete_generation", { p_user_id: user.id, p_usage_day: fallbackDay, p_success: false });
    return jsonError("A reserva diária não retornou a data de consumo.", 503);
  }
  let reservationFinalized = false;
  try {
    const base = (process.env.AI_API_BASE_URL ?? "https://api.openai.com/v1").replace(/\/$/, "");
    const response = await fetch(`${base}/chat/completions`, {
      method: "POST",
      headers: { Authorization: `Bearer ${process.env.AI_API_KEY}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        model: process.env.AI_MODEL,
        temperature: 0.55,
        response_format: { type: "json_object" },
        messages: [
          { role: "system", content: "Você é um diretor de conteúdo web. Responda somente JSON válido com as chaves title, subtitle, about, sections. Crie uma estrutura original, adequada à categoria e à direção visual informadas. Nunca invente telefone, endereço, horário, preço, produto, depoimento, avaliação, credencial ou qualquer fato comercial que não esteja nos dados recebidos. Se um dado não foi fornecido, deixe em branco ou omita a seção. sections deve ser uma lista de até 5 objetos {heading, body}. Não use emojis, frases genéricas como 'bem-vindo ao futuro' nem alegações sem prova. Escreva em português brasileiro." },
          { role: "user", content: JSON.stringify(parsed.data) },
        ],
      }),
      signal: AbortSignal.timeout(45000),
      cache: "no-store",
    });
    const modelResult = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(modelResult.error?.message ?? "O provedor de IA não conseguiu concluir a geração.");
    const modelText = modelResult.choices?.[0]?.message?.content;
    if (typeof modelText !== "string" || !modelText.trim()) throw new Error("O provedor retornou uma resposta vazia.");
    const generated = parseModelJson(modelText);

    const productLines = (parsed.data.products ?? "").split(/\r?\n/).map((line) => line.trim()).filter(Boolean).slice(0, 24);
    const products = productLines.map((line) => {
      const [productName = "", description = "", price = ""] = line.split("|").map((part) => part.trim());
      return { id: crypto.randomUUID(), name: productName.slice(0, 100), description: description.slice(0, 700), price: price.slice(0, 60), imageUrl: "" };
    }).filter((item) => item.name || item.description);

    const serviceSections = (parsed.data.services ?? "").split(/\r?\n/).map((line) => line.trim()).filter(Boolean).slice(0, 5)
      .map((line) => ({ heading: line.slice(0, 100), body: "" }));

    const content = {
      title: typeof generated.title === "string" ? generated.title.slice(0, 120) : parsed.data.name,
      subtitle: typeof generated.subtitle === "string" ? generated.subtitle.slice(0, 500) : parsed.data.description,
      about: typeof generated.about === "string" ? generated.about.slice(0, 1600) : parsed.data.description,
      contact: parsed.data.whatsapp ?? "",
      accent: "#8f685e",
      sections: [
        ...(Array.isArray(generated.sections) ? generated.sections.slice(0, 5).map((section) => ({
          heading: typeof section?.heading === "string" ? section.heading.slice(0, 100) : "",
          body: typeof section?.body === "string" ? section.body.slice(0, 700) : "",
        })) : []),
        ...serviceSections,
      ].slice(0, 10),
      products,
      contactEmail: parsed.data.email ?? "",
      phone: parsed.data.phone ?? "",
      address: parsed.data.address ?? "",
      logoUrl: "",
      heroImageUrl: "",
      footer: "",
      fontFamily: "serif",
      business: { city: parsed.data.city ?? "", address: parsed.data.address ?? "", category: parsed.data.category },
      visualStyle: parsed.data.style ?? "editorial e acolhedor",
    };

    const { data: website, error: insertError } = await admin.from("websites").insert({
      user_id: user.id,
      name: parsed.data.name,
      category: parsed.data.category,
      status: "draft",
      content,
      generation_source: "ai",
    }).select("id,name,status,created_at").single();
    if (insertError || !website) throw new Error("A estrutura foi criada, mas não pôde ser salva. Tente novamente.");
    const { error: completeError } = await admin.rpc("complete_generation", { p_user_id: user.id, p_usage_day: reservationDay, p_success: true });
    if (completeError) {
      await admin.from("websites").delete().eq("id", website.id).eq("user_id", user.id);
      throw new Error("Não foi possível confirmar o consumo da geração. Nenhuma geração foi contabilizada.");
    }
    reservationFinalized = true;
    await admin.from("platform_events").insert({ user_id: user.id, event_type: "website.generated", payload: { website_id: website.id } });
    return NextResponse.json({ website, remaining: reservation.remaining_after_reservation });
  } catch (error) {
    if (!reservationFinalized) await admin.rpc("complete_generation", { p_user_id: user.id, p_usage_day: reservationDay, p_success: false });
    return jsonError(error instanceof Error ? error.message : "Falha inesperada na geração.", 502);
  }
}
