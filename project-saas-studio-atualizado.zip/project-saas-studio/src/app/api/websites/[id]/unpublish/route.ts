import { NextResponse } from "next/server";
import { createSupabaseServerClient } from "@/lib/supabase/server";
import { createSupabaseAdminClient } from "@/lib/supabase/admin";
import { checkUserRateLimit } from "@/lib/rate-limit";

export async function POST(_request: Request, context: { params: Promise<{ id: string }> }) {
  const { id } = await context.params;
  const auth = await createSupabaseServerClient();
  const { data: { user } } = await auth.auth.getUser();
  if (!user) return NextResponse.json({ error: "Entre na sua conta para despublicar." }, { status: 401 });
  const rate = await checkUserRateLimit(user.id, "site.unpublish", 10, 60);
  if (!rate.available) return NextResponse.json({ error: "O controle de segurança está indisponível. Tente novamente." }, { status: 503 });
  if (!rate.allowed) return NextResponse.json(
    { error: "Muitas tentativas de despublicação em sequência. Aguarde e tente novamente." },
    { status: 429, headers: { "Retry-After": String(rate.retryAfterSeconds) } },
  );

  const admin = createSupabaseAdminClient();
  const { data: updated, error } = await admin.from("websites").update({
    status: "unpublished",
    updated_at: new Date().toISOString(),
  }).eq("id", id).eq("user_id", user.id).select("id,name,slug,status").single();
  if (error || !updated) {
    if (error?.code === "PGRST116") return NextResponse.json({ error: "Projeto não encontrado." }, { status: 404 });
    return NextResponse.json({ error: "Não foi possível confirmar a despublicação." }, { status: 503 });
  }

  const { error: eventError } = await admin.from("platform_events").insert({
    user_id: user.id,
    event_type: "website.unpublished",
    payload: { website_id: id, slug: updated.slug },
  });
  return NextResponse.json({
    website: updated,
    auditEventRecorded: !eventError,
    warning: eventError ? "O site foi despublicado, mas o evento de auditoria não pôde ser registrado." : undefined,
  });
}
