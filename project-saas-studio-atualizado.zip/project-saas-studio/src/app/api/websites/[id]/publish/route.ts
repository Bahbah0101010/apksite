import { NextResponse } from "next/server";
import { createSupabaseServerClient } from "@/lib/supabase/server";
import { createSupabaseAdminClient } from "@/lib/supabase/admin";
import { slugify } from "@/lib/format";
import { getRequestOrigin } from "@/lib/http";
import { hasPublishingEntitlement } from "@/lib/plans";
import { checkUserRateLimit } from "@/lib/rate-limit";

export async function POST(request: Request, context: { params: Promise<{ id: string }> }) {
  const { id } = await context.params;
  const supabase = await createSupabaseServerClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "Entre na sua conta para publicar." }, { status: 401 });
  const rate = await checkUserRateLimit(user.id, "site.publish", 10, 60);
  if (!rate.available) return NextResponse.json({ error: "O controle de segurança está indisponível. Tente novamente." }, { status: 503 });
  if (!rate.allowed) return NextResponse.json(
    { error: "Muitas tentativas de publicação em sequência. Aguarde e tente novamente." },
    { status: 429, headers: { "Retry-After": String(rate.retryAfterSeconds) } },
  );

  const { data: subscription, error: subscriptionError } = await supabase
    .from("subscriptions")
    .select("plan_code,status,current_period_end")
    .eq("user_id", user.id)
    .in("status", ["active", "trialing"])
    .gt("current_period_end", new Date().toISOString())
    .order("created_at", { ascending: false })
    .limit(1)
    .maybeSingle();
  if (subscriptionError) return NextResponse.json({ error: "Não foi possível validar seu plano agora." }, { status: 503 });
  if (!subscription || !hasPublishingEntitlement({
    planCode: subscription.plan_code,
    status: subscription.status,
    currentPeriodEnd: subscription.current_period_end,
  })) {
    return NextResponse.json({ error: "A publicação exige um plano Professional ou Business ativo." }, { status: 403 });
  }

  const { data: website, error: readError } = await supabase.from("websites").select("id,name,slug,status,content").eq("id", id).eq("user_id", user.id).single();
  if (readError || !website) return NextResponse.json({ error: "Projeto não encontrado." }, { status: 404 });

  const admin = createSupabaseAdminClient();
  let slug = website.slug || slugify(website.name);
  if (!slug) return NextResponse.json({ error: "Escolha um nome válido para o projeto." }, { status: 400 });
  const { data: conflict, error: conflictError } = await admin.from("websites")
    .select("id").eq("slug", slug).neq("id", id).maybeSingle();
  if (conflictError) return NextResponse.json({ error: "Não foi possível verificar a disponibilidade do endereço." }, { status: 503 });
  if (conflict) {
    const suffix = id.replaceAll("-", "");
    slug = `${slug.slice(0, Math.max(1, 110 - suffix.length))}-${suffix}`;
    const { data: secondConflict, error: secondCheckError } = await admin.from("websites")
      .select("id").eq("slug", slug).neq("id", id).maybeSingle();
    if (secondCheckError) return NextResponse.json({ error: "Não foi possível verificar a disponibilidade do endereço." }, { status: 503 });
    if (secondConflict) return NextResponse.json({ error: "Não há um endereço disponível para este projeto. Altere o nome e tente novamente." }, { status: 409 });
  }

  const { data: updated, error } = await admin.from("websites").update({
    slug,
    status: "published",
    published_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  }).eq("id", id).eq("user_id", user.id).select("id,name,slug,status,published_at").single();
  if (error || !updated) {
    if (error?.code === "23505") return NextResponse.json({ error: "Este endereço acabou de ser ocupado. Tente publicar novamente." }, { status: 409 });
    return NextResponse.json({ error: "A infraestrutura não confirmou a publicação." }, { status: 503 });
  }
  const { error: eventError } = await admin.from("platform_events").insert({
    user_id: user.id, event_type: "website.published", payload: { website_id: id, slug },
  });
  return NextResponse.json({
    website: updated,
    url: `${getRequestOrigin(request)}/s/${slug}`,
    auditEventRecorded: !eventError,
    warning: eventError ? "O site foi publicado, mas o evento de auditoria não pôde ser registrado." : undefined,
  });
}
