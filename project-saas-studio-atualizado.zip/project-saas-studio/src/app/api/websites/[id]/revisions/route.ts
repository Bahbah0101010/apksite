import { NextResponse } from "next/server";
import { createSupabaseServerClient } from "@/lib/supabase/server";

export async function GET(_request: Request, context: { params: Promise<{ id: string }> }) {
  const { id } = await context.params;
  const supabase = await createSupabaseServerClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "Não autenticado." }, { status: 401 });

  const { data: website } = await supabase.from("websites").select("id").eq("id", id).eq("user_id", user.id).maybeSingle();
  if (!website) return NextResponse.json({ error: "Projeto não encontrado." }, { status: 404 });

  const { data, error } = await supabase.from("website_revisions")
    .select("id,name,content,created_at")
    .eq("website_id", id)
    .eq("user_id", user.id)
    .order("created_at", { ascending: false })
    .limit(25);
  if (error) return NextResponse.json({ error: "Não foi possível consultar o histórico." }, { status: 503 });
  return NextResponse.json({ revisions: data ?? [] });
}
