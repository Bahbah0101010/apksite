import { NextResponse } from "next/server";
import { createSupabaseServerClient } from "@/lib/supabase/server";
import { createSupabaseAdminClient } from "@/lib/supabase/admin";

export async function POST(_request: Request, context: { params: Promise<{ id: string; revisionId: string }> }) {
  const { id, revisionId } = await context.params;
  const supabase = await createSupabaseServerClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "Não autenticado." }, { status: 401 });

  const { data: current } = await supabase.from("websites").select("id,name,content")
    .eq("id", id).eq("user_id", user.id).maybeSingle();
  if (!current) return NextResponse.json({ error: "Projeto não encontrado." }, { status: 404 });

  const { data: revision } = await supabase.from("website_revisions")
    .select("id,name,content")
    .eq("id", revisionId).eq("website_id", id).eq("user_id", user.id).maybeSingle();
  if (!revision) return NextResponse.json({ error: "Versão não encontrada." }, { status: 404 });

  const admin = createSupabaseAdminClient();
  const { error: archiveError } = await admin.from("website_revisions").insert({
    website_id: id, user_id: user.id, name: current.name, content: current.content ?? {},
  });
  if (archiveError) return NextResponse.json({ error: "Não foi possível preservar a versão atual." }, { status: 503 });

  const { data: website, error } = await supabase.from("websites").update({
    name: revision.name,
    content: revision.content,
    updated_at: new Date().toISOString(),
  }).eq("id", id).eq("user_id", user.id).select("id,name,content,status,slug").single();
  if (error || !website) return NextResponse.json({ error: "Não foi possível restaurar a versão." }, { status: 503 });
  const { data: olderRevisions } = await admin.from("website_revisions")
    .select("id").eq("website_id", id).eq("user_id", user.id)
    .order("created_at", { ascending: false }).range(25, 999);
  if (olderRevisions?.length) {
    await admin.from("website_revisions").delete().in("id", olderRevisions.map((item) => item.id));
  }
  return NextResponse.json({ website });
}
