import { NextResponse } from "next/server";
import { z } from "zod";
import { createSupabaseServerClient } from "@/lib/supabase/server";
import { createSupabaseAdminClient } from "@/lib/supabase/admin";

const safeHttps = z.string().max(2000).refine((value) => value === "" || value.startsWith("https://"), "Use um endereço HTTPS.");
const externalLink = z.string().max(500).refine(
  (value) => value === "" || value.startsWith("https://") || value.startsWith("mailto:") || value.startsWith("tel:"),
  "Use HTTPS, mailto: ou tel:.",
);

const sectionSchema = z.object({
  heading: z.string().max(100),
  body: z.string().max(1200),
  imageUrl: safeHttps.optional(),
  buttonLabel: z.string().max(50).optional(),
  buttonUrl: externalLink.optional(),
}).strict();

const productSchema = z.object({
  id: z.string().uuid(),
  name: z.string().max(100),
  description: z.string().max(700),
  price: z.string().max(60),
  imageUrl: safeHttps,
}).strict();

const contentSchema = z.object({
  title: z.string().max(120),
  subtitle: z.string().max(500),
  about: z.string().max(1600),
  contact: z.string().max(32),
  accent: z.string().regex(/^#[0-9a-fA-F]{6}$/),
  sections: z.array(sectionSchema).max(10).optional(),
  products: z.array(productSchema).max(24).optional(),
  logoUrl: safeHttps.optional(),
  heroImageUrl: safeHttps.optional(),
  contactEmail: z.string().max(160).email().or(z.literal("")).optional(),
  phone: z.string().max(32).optional(),
  address: z.string().max(220).optional(),
  buttonLabel: z.string().max(50).optional(),
  buttonUrl: externalLink.optional(),
  footer: z.string().max(500).optional(),
  fontFamily: z.enum(["serif", "sans"]).optional(),
  business: z.object({
    city: z.string().max(90).optional(),
    address: z.string().max(220).optional(),
    category: z.string().max(60).optional(),
  }).optional(),
  visualStyle: z.string().max(80).optional(),
});

const updateSchema = z.object({
  name: z.string().trim().min(2).max(80),
  content: contentSchema,
});

function stableJson(value: unknown): string {
  if (Array.isArray(value)) return `[${value.map(stableJson).join(",")}]`;
  if (value && typeof value === "object") {
    const record = value as Record<string, unknown>;
    return `{${Object.keys(record).sort().map((key) => `${JSON.stringify(key)}:${stableJson(record[key])}`).join(",")}}`;
  }
  return JSON.stringify(value) ?? "null";
}

export async function PATCH(request: Request, context: { params: Promise<{ id: string }> }) {
  const { id } = await context.params;
  const parsed = updateSchema.safeParse(await request.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ error: "Dados inválidos para salvar. Confira textos, links e imagens." }, { status: 400 });

  const supabase = await createSupabaseServerClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "Não autenticado." }, { status: 401 });

  const { data: current, error: readError } = await supabase
    .from("websites")
    .select("id,name,content")
    .eq("id", id)
    .eq("user_id", user.id)
    .single();
  if (readError || !current) return NextResponse.json({ error: "Projeto não encontrado ou sem permissão." }, { status: 404 });

  const admin = createSupabaseAdminClient();
  const hasChanges = current.name !== parsed.data.name
    || stableJson(current.content ?? {}) !== stableJson(parsed.data.content);
  if (hasChanges) {
    const { error: revisionError } = await admin.from("website_revisions").insert({
      website_id: id,
      user_id: user.id,
      name: current.name,
      content: current.content ?? {},
    });
    if (revisionError) return NextResponse.json({ error: "Não foi possível preservar a versão anterior. As alterações não foram aplicadas." }, { status: 503 });
  }

  const { data, error } = await supabase.from("websites").update({
    name: parsed.data.name,
    content: parsed.data.content,
    updated_at: new Date().toISOString(),
  }).eq("id", id).eq("user_id", user.id).select("id,name,status,slug,updated_at").single();
  if (error || !data) return NextResponse.json({ error: "Não foi possível salvar o projeto." }, { status: 503 });
  const { data: olderRevisions } = await admin.from("website_revisions")
    .select("id").eq("website_id", id).eq("user_id", user.id)
    .order("created_at", { ascending: false }).range(25, 999);
  if (olderRevisions?.length) {
    await admin.from("website_revisions").delete().in("id", olderRevisions.map((revision) => revision.id));
  }
  return NextResponse.json({ website: data });
}

export async function DELETE(_request: Request, context: { params: Promise<{ id: string }> }) {
  const { id } = await context.params;
  const supabase = await createSupabaseServerClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "Não autenticado." }, { status: 401 });
  const { error } = await supabase.from("websites").delete().eq("id", id).eq("user_id", user.id);
  if (error) return NextResponse.json({ error: "Não foi possível excluir o projeto." }, { status: 403 });
  return NextResponse.json({ ok: true });
}
