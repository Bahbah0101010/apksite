/* eslint-disable @next/next/no-img-element */
import { notFound } from "next/navigation";
import Link from "next/link";
import { createSupabaseServerClient } from "@/lib/supabase/server";
import { brand } from "@/lib/brand";

function safeImage(value: unknown): string | null {
  return typeof value === "string" && value.startsWith("https://") && value.length < 2000 ? value : null;
}

function safeLink(value: unknown): string | null {
  if (typeof value !== "string" || value.length > 500) return null;
  return value.startsWith("https://") || value.startsWith("mailto:") || value.startsWith("tel:") ? value : null;
}

export default async function PublishedSitePage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const supabase = await createSupabaseServerClient();
  const { data: website } = await supabase.from("websites")
    .select("name,content,slug,status,published_at")
    .eq("slug", slug)
    .eq("status", "published")
    .maybeSingle();
  if (!website) notFound();

  const content = (website.content ?? {}) as Record<string, unknown>;
  const title = typeof content.title === "string" ? content.title : website.name;
  const subtitle = typeof content.subtitle === "string" ? content.subtitle : "";
  const about = typeof content.about === "string" ? content.about : "";
  const contact = typeof content.contact === "string" ? content.contact : "";
  const phone = typeof content.phone === "string" ? content.phone : "";
  const email = typeof content.contactEmail === "string" ? content.contactEmail : "";
  const address = typeof content.address === "string" ? content.address : "";
  const footer = typeof content.footer === "string" ? content.footer : "";
  const buttonLabel = typeof content.buttonLabel === "string" ? content.buttonLabel : "Entrar em contato";
  const configuredButtonUrl = safeLink(content.buttonUrl);
  const whatsapp = contact.replace(/\D/g, "");
  const buttonUrl = configuredButtonUrl ?? (whatsapp ? `https://wa.me/${whatsapp}` : null);
  const logoUrl = safeImage(content.logoUrl);
  const heroImageUrl = safeImage(content.heroImageUrl);
  const accent = typeof content.accent === "string" && /^#[0-9a-fA-F]{6}$/.test(content.accent) ? content.accent : "#8f685e";
  const fontFamily = content.fontFamily === "sans" ? "Arial, Helvetica, sans-serif" : "Georgia, serif";
  const sections = Array.isArray(content.sections) ? content.sections.slice(0, 10) as Array<Record<string, unknown>> : [];
  const products = Array.isArray(content.products) ? content.products.slice(0, 24) as Array<Record<string, unknown>> : [];

  return <main style={{ minHeight: "100vh", background: "#f5f1eb", padding: "18px 16px 40px" }}>
    <header style={{ maxWidth: 1080, margin: "0 auto", display: "flex", justifyContent: "space-between", alignItems: "center", gap: 12, minHeight: 54 }}>
      <Link href="/" className="brand" style={{ font: "700 17px Arial,sans-serif" }}>
        {logoUrl ? <img src={logoUrl} alt={`${website.name} — logotipo`} style={{ width: 44, height: 44, objectFit: "contain" }} /> : null}
        <span>{website.name}</span>
      </Link>
      <span style={{ fontSize: 10, color: "#77726b" }}>Publicado com {brand.name}</span>
    </header>

    <section style={{ maxWidth: 1080, minHeight: 460, margin: "28px auto 0", background: "#fffdf9", borderTop: `6px solid ${accent}`, overflow: "hidden" }}>
      {heroImageUrl ? <img src={heroImageUrl} alt="" style={{ display: "block", width: "100%", maxHeight: 410, objectFit: "cover" }} /> : null}
      <div style={{ padding: "clamp(38px,8vw,94px) 24px", textAlign: "center", display: "grid", alignContent: "center" }}>
        <div style={{ color: accent, font: "700 10px Arial,sans-serif", letterSpacing: ".18em", textTransform: "uppercase" }}>{website.name}</div>
        <h1 style={{ font: `400 clamp(42px,7vw,76px)/1.04 ${fontFamily}`, letterSpacing: "-.045em", maxWidth: 800, margin: "24px auto 18px" }}>{title}</h1>
        {subtitle && <p style={{ color: "#77726b", fontSize: 15, maxWidth: 680, margin: "0 auto", lineHeight: 1.85 }}>{subtitle}</p>}
        {buttonUrl && <div style={{ marginTop: 30 }}><a className="button" style={{ background: accent }} href={buttonUrl} target={buttonUrl.startsWith("https://") ? "_blank" : undefined} rel={buttonUrl.startsWith("https://") ? "noreferrer" : undefined}>{buttonLabel}</a></div>}
      </div>
    </section>

    {(about || sections.length > 0) && <section style={{ maxWidth: 860, margin: "18px auto", background: "#fffdf9", padding: "clamp(28px,5vw,48px)" }}>
      {about && <><h2 style={{ font: `400 32px ${fontFamily}`, margin: "0 0 12px" }}>Sobre</h2><p style={{ color: "#77726b", lineHeight: 1.9, fontSize: 14, whiteSpace: "pre-wrap" }}>{about}</p></>}
      {sections.map((section, index) => {
        const heading = typeof section.heading === "string" ? section.heading : "";
        const body = typeof section.body === "string" ? section.body : "";
        const image = safeImage(section.imageUrl);
        const href = safeLink(section.buttonUrl);
        const label = typeof section.buttonLabel === "string" ? section.buttonLabel : "";
        return <article key={index} style={{ borderTop: "1px solid #e5ded4", marginTop: 24, paddingTop: 22 }}>
          {heading && <h2 style={{ font: `400 27px ${fontFamily}`, margin: "0 0 10px" }}>{heading}</h2>}
          {body && <p style={{ color: "#77726b", lineHeight: 1.85, fontSize: 14, whiteSpace: "pre-wrap" }}>{body}</p>}
          {image && <img src={image} alt="" style={{ display: "block", width: "100%", maxHeight: 420, objectFit: "cover", marginTop: 16 }} />}
          {href && label && <p><a className="text-link" href={href} target={href.startsWith("https://") ? "_blank" : undefined} rel={href.startsWith("https://") ? "noreferrer" : undefined}>{label}</a></p>}
        </article>;
      })}
    </section>}

    {products.length > 0 && <section style={{ maxWidth: 1080, margin: "18px auto", background: "#fffdf9", padding: "clamp(24px,4vw,42px)" }}>
      <h2 style={{ font: `400 32px ${fontFamily}`, margin: "0 0 22px" }}>Produtos e serviços</h2>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(min(100%,230px),1fr))", gap: 14 }}>
        {products.map((product, index) => {
          const name = typeof product.name === "string" ? product.name : "";
          const description = typeof product.description === "string" ? product.description : "";
          const price = typeof product.price === "string" ? product.price : "";
          const image = safeImage(product.imageUrl);
          if (!name && !description) return null;
          return <article key={typeof product.id === "string" ? product.id : index} style={{ border: "1px solid #e5ded4", padding: 12, background: "#fffdf9" }}>
            {image && <img src={image} alt={name} style={{ display: "block", width: "100%", height: 180, objectFit: "cover", marginBottom: 12 }} />}
            {name && <h3 style={{ font: `400 21px ${fontFamily}`, margin: "0 0 8px" }}>{name}</h3>}
            {description && <p style={{ color: "#77726b", lineHeight: 1.75, fontSize: 13, whiteSpace: "pre-wrap" }}>{description}</p>}
            {price && <strong style={{ color: accent }}>{price}</strong>}
          </article>;
        })}
      </div>
    </section>}

    {(phone || email || address) && <section style={{ maxWidth: 860, margin: "18px auto", background: "#fffdf9", padding: "25px 30px" }}>
      <h2 style={{ font: `400 27px ${fontFamily}`, margin: "0 0 12px" }}>Contato</h2>
      {phone && <p style={{ margin: "6px 0", color: "#77726b" }}>Telefone: {phone}</p>}
      {email && <p style={{ margin: "6px 0", color: "#77726b" }}>E-mail: <a href={`mailto:${email}`} className="text-link">{email}</a></p>}
      {address && <p style={{ margin: "6px 0", color: "#77726b" }}>Endereço: {address}</p>}
    </section>}

    <footer style={{ maxWidth: 1080, margin: "26px auto", textAlign: "center", color: "#847d75", fontSize: 11, lineHeight: 1.8, whiteSpace: "pre-wrap" }}>
      {footer || `Informações fornecidas pelo responsável por ${website.name}.`}
    </footer>
  </main>;
}
