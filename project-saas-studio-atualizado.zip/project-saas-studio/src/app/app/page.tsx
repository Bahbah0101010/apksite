import Link from "next/link";
import { requireUser } from "@/lib/auth";
import { PLANS, formatBRL } from "@/lib/plans";

function dayInSaoPaulo() {
  return new Intl.DateTimeFormat("en-CA", { timeZone: "America/Sao_Paulo", year: "numeric", month: "2-digit", day: "2-digit" }).format(new Date());
}

export default async function DashboardPage() {
  const { supabase, user } = await requireUser();
  const [{ data: sites }, { data: subscription }, { data: usage }, { count: publishedCount, error: publishedError }] = await Promise.all([
    supabase.from("websites").select("id,name,status,slug,created_at").eq("user_id", user.id).order("created_at", { ascending: false }).limit(8),
    supabase.from("subscriptions").select("plan_code,status,current_period_end").eq("user_id", user.id).order("created_at", { ascending: false }).limit(1).maybeSingle(),
    supabase.from("generation_usage").select("successful_count").eq("user_id", user.id).eq("usage_day", dayInSaoPaulo()).maybeSingle(),
    supabase.from("websites").select("id", { count: "exact", head: true }).eq("user_id", user.id).eq("status", "published"),
  ]);
  const planCode = subscription?.plan_code ?? "free";
  const basePlan = PLANS[planCode as keyof typeof PLANS] ?? PLANS.free;
  const entitlementActive = Boolean(subscription && ["active", "trialing"].includes(subscription.status) && subscription.current_period_end && new Date(subscription.current_period_end) > new Date());
  const plan = { ...basePlan, dailyLimit: entitlementActive ? basePlan.dailyLimit : 0 };
  const used = usage?.successful_count ?? 0;
  const remaining = Math.max(0, plan.dailyLimit - used);
  const publishedLabel = publishedError || publishedCount === null ? "Indisponível" : publishedCount.toLocaleString("pt-BR");

  return <>
    <div className="app-topbar"><div><h1>Bom ter você por aqui.</h1><p>Este é o resumo atual dos seus projetos e da sua conta.</p></div><span className="user-chip">{user.email}</span></div>
    <div className="metric-grid">
      <article className="metric-card"><span>Plano atual</span><strong style={{ fontSize: 24 }}>{entitlementActive ? plan.name : "Expirado"}</strong></article>
      <article className="metric-card"><span>Gerações usadas hoje</span><strong>{used} / {plan.dailyLimit}</strong></article>
      <article className="metric-card"><span>Gerações restantes</span><strong>{remaining}</strong></article>
      <article className="metric-card"><span>Sites publicados</span><strong>{publishedLabel}</strong></article>
    </div>
    <section className="panel">
      <div className="panel-head"><div><h2>Seus projetos</h2><p>Os sites que você criou nesta conta.</p></div><Link href="/app/sites/new" className="button">Criar site</Link></div>
      {(sites ?? []).length === 0 ? <div className="empty-state">Você ainda não criou um site. Comece pelo nome e pela descrição do seu negócio.</div> : <div className="site-list">{(sites ?? []).map((site) => <Link className="site-row" href={`/app/sites/${site.id}`} key={site.id}><div><strong>{site.name}</strong><small>Criado em {new Date(site.created_at).toLocaleDateString("pt-BR", { timeZone: "America/Sao_Paulo" })}</small></div><span className={`status ${site.status === "published" ? "good" : ""}`}>{site.status === "published" ? "Publicado" : "Rascunho"}</span></Link>)}</div>}
    </section>
    <section className="panel" style={{ display: "flex", justifyContent: "space-between", gap: 20, alignItems: "center", flexWrap: "wrap" }}>
      <div><div className="eyebrow">Seu plano</div><h2 style={{ font: "400 24px Georgia,serif", margin: "8px 0 4px" }}>{plan.name} · {formatBRL(plan.priceCents)}</h2><p style={{ color: "var(--muted)", fontSize: 11, margin: 0 }}>{subscription?.current_period_end ? `Período final: ${new Date(subscription.current_period_end).toLocaleDateString("pt-BR", { timeZone: "America/Sao_Paulo" })}` : "Nenhum período ativo cadastrado."}</p></div>
      <Link className="button secondary" href="/app/assinatura">Ver planos e pagamentos</Link>
    </section>
  </>;
}
