import { requireUser } from "@/lib/auth";
import { PLANS, formatBRL } from "@/lib/plans";
import { formatDate } from "@/lib/format";
import { PlanCheckoutButton } from "@/components/plan-checkout-button";

export default async function SubscriptionPage() {
  const { supabase, user } = await requireUser();
  const [{ data: current }, { data: payments }] = await Promise.all([
    supabase.from("subscriptions").select("plan_code,status,current_period_start,current_period_end").eq("user_id", user.id).order("created_at", { ascending: false }).limit(1).maybeSingle(),
    supabase.from("payments").select("id,plan_code,status,amount_cents,created_at,approved_at,mode").eq("user_id", user.id).order("created_at", { ascending: false }).limit(20),
  ]);
  const plan = PLANS[(current?.plan_code ?? "free") as keyof typeof PLANS] ?? PLANS.free;
  const active = current?.status === "active" && current.current_period_end && new Date(current.current_period_end) > new Date();
  return <>
    <div className="app-topbar"><div><h1>Plano e pagamentos</h1><p>Consulte seu acesso e o histórico das transações desta conta.</p></div></div>
    <section className="panel"><div className="panel-head"><div><h2>Seu plano atual</h2><p>O acesso é liberado após a confirmação do pagamento pelo webhook.</p></div><span className={`status ${active ? "good" : "warn"}`}>{active ? "Ativo" : "Expirado ou inativo"}</span></div>
      <div style={{ display: "flex", alignItems: "end", gap: 20, justifyContent: "space-between", flexWrap: "wrap" }}><div><div style={{ font: "34px Georgia,serif" }}>{plan.name}</div><div style={{ font: "25px Georgia,serif", marginTop: 8 }}>{formatBRL(plan.priceCents)} <span style={{ font: "11px Arial", color: "var(--muted)" }}>{plan.billing}</span></div><p style={{ color: "var(--muted)", fontSize: 11 }}>Período atual: {formatDate(current?.current_period_start)} até {formatDate(current?.current_period_end)}</p></div><div className="status">Renovação manual pelo checkout</div></div>
    </section>
    <section className="panel"><div className="panel-head"><div><h2>Planos disponíveis</h2><p>Pagamentos avulsos. A renovação é manual; não há cobrança automática neste checkout.</p></div></div>
      <div className="pricing-grid">{(["professional","business"] as const).map((code) => { const item = PLANS[code]; return <article className="price-card" key={code}><div className="price-name">{item.name}</div><div className="price-value">{formatBRL(item.priceCents)}</div><div className="price-period">{item.billing}</div><ul className="price-list">{item.features.map((f) => <li key={f}>{f}</li>)}</ul><PlanCheckoutButton planCode={code} label={`Contratar ${item.name}`} /></article>; })}</div>
    </section>
    <section className="panel"><div className="panel-head"><div><h2>Histórico de pagamentos</h2><p>Transações consultadas no banco de dados.</p></div></div>
      {!payments?.length ? <div className="empty-state">Nenhum pagamento registrado.</div> : <div className="table-wrap"><table><thead><tr><th>Plano</th><th>Valor</th><th>Status</th><th>Data</th><th>Ambiente</th></tr></thead><tbody>{payments.map((payment) => <tr key={payment.id}><td>{PLANS[payment.plan_code as keyof typeof PLANS]?.name ?? payment.plan_code}</td><td>{formatBRL(payment.amount_cents)}</td><td><span className={`status ${payment.status === "approved" ? "good" : payment.status === "pending" ? "warn" : "bad"}`}>{payment.status}</span></td><td>{formatDate(payment.approved_at ?? payment.created_at)}</td><td>{payment.mode === "live" ? "Produção" : "Teste"}</td></tr>)}</tbody></table></div>}
    </section>
  </>;
}
