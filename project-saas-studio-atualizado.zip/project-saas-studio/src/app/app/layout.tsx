import type { ReactNode } from "react";
import { requireUser, isAllowedAdmin } from "@/lib/auth";
import { AppSidebar } from "@/components/app-sidebar";
import { Heartbeat } from "@/components/heartbeat";

export default async function AppLayout({ children }: Readonly<{ children: ReactNode }>) {
  const { user } = await requireUser();
  return <div className="app-layout">
    <AppSidebar email={user.email ?? "Conta"} admin={isAllowedAdmin(user.email)} />
    <main className="app-main">{children}</main>
    <Heartbeat />
  </div>;
}
