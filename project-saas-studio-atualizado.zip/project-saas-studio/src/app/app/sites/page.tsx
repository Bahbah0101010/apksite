import Link from "next/link";
import { requireUser } from "@/lib/auth";

export default async function SitesPage() {
  const { supabase, user } = await requireUser();
  const { data: sites, error } = await supabase.from("websites").select("id,name,status,slug,created_at").eq("user_id", user.id).order("created_at", { ascending: false });
  return <>
    <div className="app-topbar"><div><h1>Meus sites</h1><p>Rascunhos e páginas que já foram publicadas.</p></div><Link href="/app/sites/new" className="button">Novo site</Link></div>
    <section className="panel">
      {error ? <div className="empty-state">Não foi possível carregar seus projetos. Atualize a página ou tente novamente.</div> : (sites ?? []).length === 0 ? <div className="empty-state">Nenhum site cadastrado nesta conta.</div> : <div className="site-list">{sites!.map((site) => <Link className="site-row" href={`/app/sites/${site.id}`} key={site.id}><div><strong>{site.name}</strong><small>{site.slug ? `/s/${site.slug}` : "Ainda sem endereço público"}</small></div><span className={`status ${site.status === "published" ? "good" : ""}`}>{site.status === "published" ? "Publicado" : "Rascunho"}</span></Link>)}</div>}
    </section>
  </>;
}
