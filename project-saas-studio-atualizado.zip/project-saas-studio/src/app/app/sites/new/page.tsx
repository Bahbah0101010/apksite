import { requireUser } from "@/lib/auth";
import { SiteGenerator } from "@/components/site-generator";

export default async function NewSitePage() {
  await requireUser();
  return <><div className="app-topbar"><div><h1>Criar um novo site</h1><p>Uma estrutura inicial feita a partir das informações do seu negócio.</p></div></div><SiteGenerator /></>;
}
