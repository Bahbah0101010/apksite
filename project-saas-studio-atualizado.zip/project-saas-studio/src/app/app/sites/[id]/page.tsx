import { notFound } from "next/navigation";
import { requireUser } from "@/lib/auth";
import { WebsiteEditor, type WebsiteContent } from "@/components/website-editor";

export default async function WebsiteEditorPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const { supabase, user } = await requireUser();
  const { data: website, error } = await supabase.from("websites").select("id,name,status,slug,content").eq("id", id).eq("user_id", user.id).single();
  if (error || !website) notFound();
  const raw = (website.content ?? {}) as Partial<WebsiteContent>;
  const initialContent: WebsiteContent = {
    title: raw.title ?? website.name,
    subtitle: raw.subtitle ?? "",
    about: raw.about ?? "",
    contact: raw.contact ?? "",
    accent: raw.accent ?? "#8f685e",
    sections: Array.isArray(raw.sections) ? raw.sections.slice(0, 10) : [],
    products: Array.isArray(raw.products) ? raw.products.slice(0, 24) as WebsiteContent["products"] : [],
    logoUrl: typeof raw.logoUrl === "string" ? raw.logoUrl : "",
    heroImageUrl: typeof raw.heroImageUrl === "string" ? raw.heroImageUrl : "",
    contactEmail: typeof raw.contactEmail === "string" ? raw.contactEmail : "",
    phone: typeof raw.phone === "string" ? raw.phone : "",
    address: typeof raw.address === "string" ? raw.address : "",
    buttonLabel: typeof raw.buttonLabel === "string" ? raw.buttonLabel : "",
    buttonUrl: typeof raw.buttonUrl === "string" ? raw.buttonUrl : "",
    footer: typeof raw.footer === "string" ? raw.footer : "",
    fontFamily: raw.fontFamily === "sans" ? "sans" : "serif",
    business: {
      city: typeof raw.business?.city === "string" ? raw.business.city : "",
      address: typeof raw.business?.address === "string" ? raw.business.address : "",
      category: typeof raw.business?.category === "string" ? raw.business.category : "",
    },
    visualStyle: typeof raw.visualStyle === "string" ? raw.visualStyle : "",
  };
  const appUrl = process.env.NEXT_PUBLIC_APP_URL?.replace(/\/$/, "") ?? "";
  const publishedUrl = website.slug && appUrl ? `${appUrl}/s/${website.slug}` : website.slug ? `/s/${website.slug}` : null;
  return <><div className="app-topbar"><div><h1>{website.name}</h1><p>Edite o conteúdo e acompanhe a pré-visualização.</p></div></div><WebsiteEditor websiteId={website.id} initialName={website.name} initialContent={initialContent} initialStatus={website.status} publishedUrl={publishedUrl} /></>;
}
