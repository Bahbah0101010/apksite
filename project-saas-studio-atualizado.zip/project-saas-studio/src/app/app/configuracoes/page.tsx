import { requireUser } from "@/lib/auth";

export default async function SettingsPage() {
  const { supabase, user } = await requireUser();
  const { data: profile } = await supabase.from("profiles").select("full_name,created_at").eq("id", user.id).maybeSingle();
  return <><div className="app-topbar"><div><h1>Configurações</h1><p>Informações da conta autenticada.</p></div></div>
    <section className="panel" style={{ maxWidth: 700 }}><div className="panel-head"><div><h2>Dados da conta</h2><p>As informações abaixo vêm do Supabase Auth e do perfil.</p></div></div>
      <div className="field"><label>E-mail</label><input value={user.email ?? ""} readOnly /></div>
      <div className="field"><label>Nome</label><input value={profile?.full_name ?? "Não informado"} readOnly /></div>
      <div className="field"><label>Cadastro</label><input value={new Date(user.created_at).toLocaleString("pt-BR", { timeZone: "America/Sao_Paulo" })} readOnly /></div>
      <p style={{ color: "var(--muted)", fontSize: 11 }}>Recuperação de senha e alteração de e-mail devem ser feitas pelo fluxo de autenticação do Supabase. A exclusão de conta precisa ser confirmada pelo backend antes de ser habilitada.</p>
    </section></>;
}
