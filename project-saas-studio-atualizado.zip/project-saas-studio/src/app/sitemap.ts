import type { MetadataRoute } from "next";

export default function sitemap(): MetadataRoute.Sitemap {
  const base = process.env.NEXT_PUBLIC_APP_URL ?? "https://example.invalid";
  return ["/", "/login", "/signup"].map((path) => ({ url: `${base.replace(/\/$/, "")}${path}`, lastModified: new Date() }));
}
