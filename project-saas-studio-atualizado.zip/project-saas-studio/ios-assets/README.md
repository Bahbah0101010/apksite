# Recurso de ícone iOS

`AppIcon.appiconset` contém o catálogo de ícone 1024×1024 derivado da fotografia enviada.
Após `npx cap add ios`, copie esse diretório para `ios/App/App/Assets.xcassets/`
(substituindo somente o catálogo AppIcon gerado) e valide no Xcode. A geração e assinatura
do app iOS requerem macOS e Xcode.
