IDENTIDADE VISUAL DO APLICATIVO

A fotografia quadrada enviada pelo proprietário já foi incorporada. O arquivo original foi mantido em source-photo-original.jpg (1536 x 1536):
- icon.png: master de ícone 1024 x 1024, sem alteração de composição.
- splash.png: composição 2732 x 2732 baseada na mesma imagem.

A fotografia também está disponível em public/brand/cover.jpg e nos assets web/PWA.
Para gerar recursos nativos após adicionar plataformas, execute:
  npm run mobile:assets

Não substitua a fotografia por outra sem autorização.
