# Auditoria técnica e registro de desenvolvimento — PROJECT SAAS STUDIO

**Data da revisão:** 30/10/2026  
**Base recebida:** `project-saas-studio.zip`  
**Abordagem:** continuidade do código existente; sem recriação da aplicação.

## 1. Resultado da inspeção do ZIP

O arquivo foi extraído e a árvore do projeto foi inspecionada antes das alterações. O pacote continha aproximadamente 106 entradas e cerca de 151 KB descompactados na versão recebida.

### Arquitetura encontrada

- Next.js 16 com App Router, React 19 e TypeScript.
- Supabase SSR/JS, PostgreSQL e políticas RLS.
- Integração de geração de conteúdo por API compatível com OpenAI Chat Completions.
- Checkout Pro do Mercado Pago, endpoint de webhook e função SQL transacional para processar pagamentos.
- Painel de administração e métricas alimentadas por função SQL.
- Editor inicial de sites, rota pública por slug e analytics condicionado ao consentimento.
- Heartbeat de sessões autenticadas e integração com Supabase Realtime.
- Configuração inicial Capacitor, mas sem diretório Android nativo e sem APK.
- Testes unitários para assinatura do Mercado Pago e configuração dos planos.

### Componentes SQL encontrados

A migration `0001_initial.sql` contém tabelas para planos, perfis, assinaturas, sites, seções, produtos, assets, domínios, consumo de gerações, pagamentos, eventos, sessões, analytics e logs de auditoria. As tabelas centrais têm RLS habilitado, com políticas de leitura por proprietário/administrador. Funções privilegiadas incluem reserva e finalização de cotas, métricas administrativas e processamento transacional do Mercado Pago.

A função `reserve_generation` bloqueia a linha diária de uso durante a reserva, verifica o limite do plano vigente e contabiliza a geração somente após finalização bem-sucedida. O período diário usa `America/Sao_Paulo`.

### Integrações existentes — não equivalem a homologação

- **IA:** chamada ao provedor ocorre no backend; chave não é enviada ao navegador. A rota reserva a cota antes da chamada e confirma ou libera a reserva depois.
- **Mercado Pago:** cria preferência no backend; o webhook valida HMAC, consulta o pagamento na API do Mercado Pago e passa os dados a uma função SQL idempotente que compara valor, moeda, ambiente e referência antes de ativar uma assinatura.
- **Realtime/presença:** a base já inclui heartbeat autenticado e publicação de tabelas para Realtime. A presença online é calculada a partir de sessões com heartbeat recente; não representa visitantes anônimos.
- **Publicação:** a base já renderiza sites publicados em `/s/[slug]`; não havia automação de subdomínios wildcard, DNS ou TLS personalizado.

## 2. Riscos e lacunas identificados

1. A permissão de UPDATE de `websites` originalmente permitia ao dono alterar campos além do conteúdo editorial, incluindo `status` e `slug`. Isso permitia contornar o endpoint de publicação.
2. O editor inicial não oferecia uma edição suficiente de seções e produtos, upload de assets ou histórico de versões.
3. Não havia fluxo de despublicação.
4. Não havia recuperação de senha na interface.
5. O painel administrativo não apresentava indicadores próprios de consumo de IA.
6. O ZIP recebido não incluía `android/`, projeto Xcode ou APK compilado.
7. O editor e a geração inicial precisavam preservar e transportar os dados comerciais informados com mais fidelidade.
8. O pacote não implementava renovação automática de cobrança; os pagamentos dos planos eram transações avulsas.
9. O fluxo de publicação não deveria liberar sites no plano Free ou com assinatura expirada.
10. O guia `COMECE_AQUI.txt` estava desatualizado em relação à fotografia enviada e às alterações entregues.

## 3. Alterações feitas nesta entrega

### Identidade visual e ícones

A fotografia enviada foi preservada como imagem original, sem substituição ou mudança de estilo. A origem já era quadrada. Foram exportadas versões redimensionadas para web, PWA, Apple Touch Icon, master Capacitor, splash e recursos Android por densidade, incluindo adaptive icon. Os arquivos-fonte estão em `resources/`, `public/icons/`, `public/brand/`, `android-assets/` e `ios-assets/`.

### Editor e sites públicos

- Campos para nome, título, descrição, sobre, WhatsApp, telefone, e-mail, endereço, CTA, rodapé, cor, tipografia, categoria, cidade e direção visual.
- Adição, remoção e reordenação de até 10 seções.
- Edição de até 24 produtos/serviços e seus preços informados.
- Upload de logo, capa e imagens de produtos para Supabase Storage; tipos aceitos JPG, PNG e WebP, até 8 MB.
- Prévia responsiva em celular, tablet e computador.
- Salvamento automático e manual.
- Histórico e restauração de versões, limitado a 25 versões recentes por site.
- Ação de despublicar.
- Renderização pública ampliada para seções, imagens, produtos/serviços, contatos, rodapé, links seguros e tipografia.
- Validação de conteúdo com Zod e filtro de URLs para restringir imagens a HTTPS e links externos a HTTPS/mailto/tel.

### Backend, segurança e publicação

- A migration 0001 foi ajustada para limitar UPDATE autenticado de `websites` às colunas editoriais `name`, `content` e `updated_at`; campos `status` e `slug` não podem ser alterados diretamente pelo usuário.
- A migration 0002 reforça os privilégios, cria `website_revisions`, configura bucket e políticas de Storage e adiciona métricas reais de uso de IA.
- A gravação de revisões ocorre com a chave de serviço apenas no servidor depois de verificar a propriedade do site. O usuário autenticado tem leitura apenas das próprias revisões.
- Rate limiting por usuário no PostgreSQL protege geração (5/min), checkout (3/min), publicação/despublicação (10/min) e consultas administrativas (30/min), além das cotas diárias de IA.
- As políticas de Storage vinculam o primeiro segmento do caminho ao UUID do site pertencente ao usuário.
- Publicação exige plano Professional ou Business ativo e ainda vigente. O slug é verificado antes da gravação e erros de colisão são tratados.
- Publicação e despublicação são operações de backend usando a chave de serviço e geram evento de plataforma; falha de auditoria é informada sem fingir que a alteração de status foi revertida.
- O endpoint administrativo agrega métricas de gerações a partir do PostgreSQL, sem números fictícios.

### IA e autenticação

- O formulário do gerador passou a enviar categoria, cidade, endereço, telefone, WhatsApp, e-mail, produtos, serviços e preferência visual.
- A rota de IA valida os campos, tem timeout de 45 segundos e monta dados de produtos/serviços a partir do que o usuário efetivamente informou.
- Adicionada solicitação e conclusão de redefinição de senha via Supabase Auth.
- Os metadados comerciais são preservados pelo editor durante o salvamento.

### Android e iOS

- Incluído `@capacitor/ios` e scripts para adicionar/sincronizar plataformas e gerar assets.
- Incluídos recursos de ícone Android por densidade/adaptativos e catálogo iOS AppIcon.
- O app planejado usa a mesma aplicação web hospedada e o mesmo backend via Capacitor `server.url`; a URL precisa ser HTTPS.
- Nenhum projeto nativo Android/iOS foi gerado neste ambiente e nenhum APK foi compilado.

## 4. Planos preservados

| Plano | Preço | Duração | Limite diário |
|---|---:|---:|---:|
| Free | R$ 0,00 | 30 dias | 10 gerações |
| Professional | R$ 97,00 | 30 dias | 30 gerações |
| Business | R$ 697,00 | 365 dias | 100 gerações |

Os valores em centavos (`0`, `9700`, `69700`), durações e cotas foram preservados em `src/lib/plans.ts` e `0001_initial.sql`. Professional e Business são cobranças avulsas com renovação manual no escopo atual; não anunciar renovação automática.

## 5. Verificações executadas

| Verificação | Resultado |
|---|---|
| Extração e inspeção do ZIP | Concluída |
| Verificação da dimensão da foto de origem | 1536 × 1536 |
| Geração e inspeção visual dos ícones | Concluída |
| Validação de sintaxe TypeScript/TSX com `transpileModule` global | 55 arquivos examinados após todas as alterações; 0 diagnósticos de sintaxe |
| Parse de JSON (`package.json`, `tsconfig.json`, manifest PWA e Contents.json iOS) | Aprovado |
| Resolução de imports locais | 52 arquivos examinados; 0 imports locais não encontrados |
| Dimensões dos ícones principais | PNGs conferidos nas dimensões esperadas para master, splash, web, iOS e Android |
| Regras dos planos executadas diretamente | 6 verificações aprovadas (preços/cotas e autorização de publicação) |
| Validação HMAC do Mercado Pago executada diretamente | Assinatura válida aceita; assinatura inválida/incompleta rejeitada |
| `npm install` | Não concluído: timeout e falha de DNS para `registry.npmjs.org` (`EAI_AGAIN`/`ENOTFOUND`) |
| `npm run typecheck`, `npm run lint`, `npm test`, `npm run build` | Não executáveis de forma válida sem dependências instaladas; a tentativa de TypeScript completa falhou por módulos e tipos ausentes |
| Aplicação das migrations num projeto Supabase | Não executada; requer projeto/credenciais Supabase do proprietário |
| IA e Mercado Pago com credenciais reais/de teste | Não executado; requer credenciais externas |
| Compilação, instalação e teste de APK | Não executados; o ambiente não contém Android SDK, Gradle ou adb |

**Importante:** validação de sintaxe TypeScript não equivale a typecheck completo nem a build Next.js. Testes unitários do Vitest não foram executados nesta máquina porque dependências não puderam ser instaladas. Nenhuma integração externa foi declarada como homologada.

## 6. O que ainda falta antes de produção

- Instalar dependências em uma máquina com acesso ao npm e executar typecheck, lint, Vitest e build; corrigir eventuais erros de integração de tipos/runtime.
- Aplicar primeiro `0001_initial.sql` e depois `0002_editor_assets_and_usage.sql` em um projeto Supabase de homologação; verificar RLS, Storage e Realtime com duas contas distintas.
- Preencher `.env.local` com Supabase URL/anon/service-role, `ADMIN_EMAILS`, provedor de IA, Mercado Pago e segredos de analytics. As chaves privadas só podem existir no servidor.
- Executar testes end-to-end: cadastro, confirmação de e-mail, login/logout, recuperação, cotas concorrentes, editor, histórico, upload, publicação, despublicação e acesso entre usuários.
- Testar checkout, Pix/cartão conforme habilitação da conta, assinatura HMAC, idempotência, recusa, reembolso e contestação em credenciais de teste; somente depois configurar produção.
- Configurar hospedagem, HTTPS, backups, monitoramento, política de privacidade/termos e revisão LGPD.
- Gerar o projeto Android com Capacitor em ambiente com JDK, Android Studio/SDK e Gradle; compilar, instalar e testar APK/AAB, deep links, navegação, conexão, notificações e assinatura. Gerar iOS em macOS/Xcode caso seja necessário entregar IPA.
- Implementar DNS wildcard, subdomínios e domínios personalizados com verificação e TLS; a rota atual de publicação é `/s/slug`.
- Completar recursos que continuam fora do escopo efetivamente implementado: CRUD administrativo completo, cancelamento/reembolso operacional pelo painel, cobrança recorrente automática, gerenciamento de domínio, SEO avançado, formulários, analytics detalhado por site e presença de visitantes anônimos.

## 7. Próxima ordem recomendada

1. Aplicar migrations e validar autorização/Storage em Supabase de homologação.
2. Instalar dependências e fechar a bateria automatizada de qualidade.
3. Homologar IA e Mercado Pago com contas de teste.
4. Gerar e testar o projeto Android com Capacitor.
5. Só então publicar em produção, com domínio/HTTPS, monitoramento, backups e credenciais reais.
